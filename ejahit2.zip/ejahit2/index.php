<?php session_start();?>


<?php
	
	if(isset($_POST['Login']))
	{
		include 'dbconnect.php';		
		$username = trim(addslashes($_POST['staff_id']));
		$password = trim(addslashes($_POST['staff_password']));
		
		if ($username != '' && $password != '') 
		{		
			$sql = "SELECT distinct ID_pengurus,
							katalaluan,
							aras,
							nama_penuh		 
					FROM pengurus
				    WHERE ID_pengurus = '$username' AND katalaluan = '$password'
					UNION 
					SELECT distinct ID_pelanggan,
							katalaluan,
							aras,
							nama_penuh		 
					FROM pelanggan
				    WHERE ID_pelanggan = '$username' AND katalaluan = '$password'";
			$result = mysql_query($sql) or die('Query failed. ' . mysql_error());
			$row = mysql_fetch_array($result, MYSQL_ASSOC);
			
			if (mysql_num_rows($result) == 1) 
			{
				$_SESSION['nama_pengguna']=$row['nama_penuh'];
				$_SESSION['id_pengguna']=$row['ID_pengurus'];
				$_SESSION['aras']=$row['aras'];
				
				if ($_SESSION['aras']=='Pengurus')
				{
					print "<script>";
					print " self.location='~/../secure_pengurus/index.php';"; 
					print "</script>";	
				}
				elseif ($_SESSION['aras']=='Pelanggan')
				{
					print "<script>";
					print " self.location='~/../secure_pelanggan/index.php';"; 
					print "</script>";	
				}																			
			} 
			else
			{
				echo "<script languange = 'Javascript'>
				alert('Sila semak ID Pengguna dan Katalaluan!!');
				location.href = 'index.php';</script>";	
			}		
		}
		else
		{
				echo "<script languange = 'Javascript'>
				alert('Sila masukkan ID Pengguna dan Katalaluan!!');
				location.href = 'index.php';</script>";	
							
		}				
	}


?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>e-tailoring </title>
<link rel="stylesheet" type="text/css" href="css/bootstrap.css"/>
<link rel="stylesheet" type="text/css" href="css/login.css"/>
<style type="text/css">
body {
	background-image:url(image/image/background1.jpg)
}
</style>
</head>

<body>
<br />
<table width="780" border="0" align="center" cellspacing="0" cellpadding="0">
  <tr>
    <td colspan="2"><img src="image/image/logo.png" /></td>
  </tr>
  
  <br /><br /><br />
  <tr>
    <td align="center">
    <form id="form1" name="form1" method="post" action="<?php echo $_SERVER['PHP_SELF'];?>">
    <table width="243" border="0">
      <tr align="left">
        <td width="83" align="right" nowrap="nowrap" ><strong><font size="1" face="Verdana, Geneva, sans-serif">ID Pengguna : </font></strong></td>
        <td width="144"><input name="staff_id" type="text" class="input-medium" id="staff_id"  /></td>
      </tr>
      <tr align="left">
        <td align="right" nowrap="nowrap" ><strong><font size="1" face="Verdana, Geneva, sans-serif">Katalaluan :</font></strong></td>
        <td><input name="staff_password" type="password" class="input-medium" id="staff_password"  /></td>
      </tr>
      <tr>
      	<td height="20">&nbsp;</td>
        <td height="20" align="left"><input  type="submit" name="Login" value="Log Masuk" class="btn btn-primary login_btn" />
        <br />
        
        <div class="regis">
                <a href="daftar_pekerja.php">Daftar Masuk?</a>
               </div>
      </tr>
      <tr>
        <td height="31" colspan="2" class="arahan"></td>
      </tr>
    </table>
  </form>  
    </td>
  <br /><br />
  <tr>
    <td colspan="2"><img src="image/image/6.jpg" width="800" height="160" /></td>
  </tr>
</table>

</body>
</html>