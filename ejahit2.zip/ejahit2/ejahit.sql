-- phpMyAdmin SQL Dump
-- version 3.3.9
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Feb 26, 2017 at 10:03 AM
-- Server version: 5.5.8
-- PHP Version: 5.3.5

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `ejahit`
--

-- --------------------------------------------------------

--
-- Table structure for table `jenis`
--

CREATE TABLE IF NOT EXISTS `jenis` (
  `bajuID` int(11) NOT NULL AUTO_INCREMENT,
  `kategori` varchar(100) DEFAULT NULL,
  `material` varchar(100) DEFAULT NULL,
  `image` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`bajuID`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=21 ;

--
-- Dumping data for table `jenis`
--

INSERT INTO `jenis` (`bajuID`, `kategori`, `material`, `image`) VALUES
(20, 'Baju Kurung', 'songket', 'musang.JPG');

-- --------------------------------------------------------

--
-- Table structure for table `pelanggan`
--

CREATE TABLE IF NOT EXISTS `pelanggan` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ID_pelanggan` varchar(6) NOT NULL,
  `katalaluan` varchar(50) DEFAULT NULL,
  `nama_penuh` varchar(150) DEFAULT NULL,
  `alamat` varchar(255) DEFAULT NULL,
  `notel` varchar(20) DEFAULT NULL,
  `aras` varchar(15) NOT NULL,
  PRIMARY KEY (`ID_pelanggan`),
  UNIQUE KEY `id` (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=10 ;

--
-- Dumping data for table `pelanggan`
--

INSERT INTO `pelanggan` (`id`, `ID_pelanggan`, `katalaluan`, `nama_penuh`, `alamat`, `notel`, `aras`) VALUES
(6, '1234', 'abc123', 'lin', 'bangi', '019988765432', 'Pelanggan'),
(7, '4564', 'abc123', 'aqilah rahman', 'kl', '0142311842', 'Pelanggan'),
(9, '5123', 'abc123', 'yusoff iskandar', 'selayang', '017354768', 'Pelanggan'),
(4, '5531', 'abc123', 'aini', 'klang', '0123456789', 'Pelanggan'),
(3, '6026', 'abc123', 'nur jannah', 'jeram selangor', '0192970215', 'Pelanggan'),
(5, '6754', 'abc123', 'aishah', 'kajang', '0198765432', ''),
(8, '9890', 'abc123', 'huda asnaf', 'perak', '0142313787', 'Pelanggan');

-- --------------------------------------------------------

--
-- Table structure for table `pengurus`
--

CREATE TABLE IF NOT EXISTS `pengurus` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ID_pengurus` varchar(6) NOT NULL,
  `katalaluan` varchar(50) DEFAULT NULL,
  `nama_penuh` varchar(150) DEFAULT NULL,
  `noKP` varchar(12) DEFAULT NULL,
  `jawatan` varchar(150) DEFAULT NULL,
  `alamat` varchar(255) DEFAULT NULL,
  `notel` varchar(20) DEFAULT NULL,
  `aras` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`ID_pengurus`),
  UNIQUE KEY `id` (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `pengurus`
--

INSERT INTO `pengurus` (`id`, `ID_pengurus`, `katalaluan`, `nama_penuh`, `noKP`, `jawatan`, `alamat`, `notel`, `aras`) VALUES
(1, '5699', '123', 'Sabrena', '870105035699', NULL, 'MALAYSIA', '0192251499', 'Pengurus');

-- --------------------------------------------------------

--
-- Table structure for table `ukuran_bajukurung`
--

CREATE TABLE IF NOT EXISTS `ukuran_bajukurung` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `bajuID` int(11) NOT NULL,
  `ID_pelanggan` varchar(6) NOT NULL,
  `bukaan_tangan` varchar(6) DEFAULT NULL,
  `lilit_ketiak` varchar(6) DEFAULT NULL,
  `ukuran_bahu` varchar(6) DEFAULT NULL,
  `ukuran_dada` varchar(6) DEFAULT NULL,
  `panjang_baju` varchar(6) DEFAULT NULL,
  `ukuran_pinggul` varchar(6) DEFAULT NULL,
  `lampiran` varchar(255) DEFAULT NULL,
  `tempah_tarikh` date DEFAULT NULL,
  `ambil_tarikh` date DEFAULT NULL,
  `transactioncode` varchar(25) DEFAULT NULL,
  PRIMARY KEY (`id`,`bajuID`,`ID_pelanggan`),
  UNIQUE KEY `id` (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=19 ;

--
-- Dumping data for table `ukuran_bajukurung`
--

INSERT INTO `ukuran_bajukurung` (`id`, `bajuID`, `ID_pelanggan`, `bukaan_tangan`, `lilit_ketiak`, `ukuran_bahu`, `ukuran_dada`, `panjang_baju`, `ukuran_pinggul`, `lampiran`, `tempah_tarikh`, `ambil_tarikh`, `transactioncode`) VALUES
(9, 10, '5112', '12', '2', '6', '10', '10', '2', '', '2013-05-17', '2013-05-24', 'ca50csp5'),
(12, 11, '6026', '10', '15', '14', '14', '13', '26', '', '2017-02-26', '2017-03-10', 'wigiv8xa'),
(13, 11, '6026', '11', '11', '11', '11', '11', '11', '', '2017-02-26', '2017-03-04', 'wigiv8xa'),
(14, 11, '1234', '11', '11', '11', '11', '11', '11', '', '2017-02-26', '0000-00-00', 'eqrp3p0s'),
(15, 11, '6026', '11', '11', '11', '11', '11', '11', '', '2017-02-26', '2017-02-04', 'o3cdhrar'),
(16, 16, '1234', '11', '11', '11', '11', '11', '11', '', '2017-02-26', '2017-02-28', '8x0isy3z'),
(17, 18, '9890', '11', '11', '11', '11', '11', '11', '', '2017-02-26', '2017-03-30', 'q8ddhc3u'),
(18, 20, '1234', '11', '11', '11', '11', '11', '11', 'musang.JPG', '2017-02-26', '2017-03-25', '47aqcids');

-- --------------------------------------------------------

--
-- Table structure for table `ukuran_bajumelayu`
--

CREATE TABLE IF NOT EXISTS `ukuran_bajumelayu` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `bajuID` int(11) NOT NULL,
  `ID_pelanggan` varchar(6) NOT NULL,
  `labuh_lengan` varchar(6) DEFAULT NULL,
  `panjang_baju` varchar(6) DEFAULT NULL,
  `lilit_leher` varchar(6) DEFAULT NULL,
  `lilit_dada` varchar(6) DEFAULT NULL,
  `lampiran` varchar(255) DEFAULT NULL,
  `tempah_tarikh` date DEFAULT NULL,
  `ambil_tarikh` date DEFAULT NULL,
  `transactioncode` varchar(25) DEFAULT NULL,
  PRIMARY KEY (`id`,`bajuID`,`ID_pelanggan`),
  UNIQUE KEY `id` (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `ukuran_bajumelayu`
--

INSERT INTO `ukuran_bajumelayu` (`id`, `bajuID`, `ID_pelanggan`, `labuh_lengan`, `panjang_baju`, `lilit_leher`, `lilit_dada`, `lampiran`, `tempah_tarikh`, `ambil_tarikh`, `transactioncode`) VALUES
(2, 13, '6026', '11', '11', '11', '11', '', '2017-02-26', '2017-02-24', 'o3cdhrar'),
(3, 13, '6026', '11', '11', '11', '11', '', '2017-02-26', '2017-02-04', 'o3cdhrar'),
(4, 17, '1234', '11', '11', '11', '11', '', '2017-02-26', '2017-02-28', '8x0isy3z');

-- --------------------------------------------------------

--
-- Table structure for table `ukuran_jubah`
--

CREATE TABLE IF NOT EXISTS `ukuran_jubah` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `bajuID` int(11) NOT NULL,
  `ID_pelanggan` varchar(6) NOT NULL,
  `lilit_leher` varchar(6) DEFAULT NULL,
  `lebar_bahu` varchar(6) DEFAULT NULL,
  `lebar_punggung` varchar(6) DEFAULT NULL,
  `lebar_lengan` varchar(6) DEFAULT NULL,
  `lebar_pinggang` varchar(6) DEFAULT NULL,
  `lebar_dada` varchar(6) DEFAULT NULL,
  `lebar_kain` varchar(6) DEFAULT NULL,
  `panjang_tangan` varchar(6) DEFAULT NULL,
  `panjang_badan` varchar(6) DEFAULT NULL,
  `panjang_baju` varchar(6) DEFAULT NULL,
  `lampiran` varchar(255) DEFAULT NULL,
  `tempah_tarikh` date DEFAULT NULL,
  `ambil_tarikh` date DEFAULT NULL,
  `transactioncode` varchar(25) DEFAULT NULL,
  PRIMARY KEY (`id`,`bajuID`,`ID_pelanggan`),
  UNIQUE KEY `id` (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `ukuran_jubah`
--

INSERT INTO `ukuran_jubah` (`id`, `bajuID`, `ID_pelanggan`, `lilit_leher`, `lebar_bahu`, `lebar_punggung`, `lebar_lengan`, `lebar_pinggang`, `lebar_dada`, `lebar_kain`, `panjang_tangan`, `panjang_badan`, `panjang_baju`, `lampiran`, `tempah_tarikh`, `ambil_tarikh`, `transactioncode`) VALUES
(1, 6, '5112', '5', '2', '5', '', '1', '', '3', '', '', '', '', '2013-05-18', '0000-00-00', 'rdmz4zva'),
(2, 14, '1234', '11', '11', '11', '11', '11', '11', '11', '11', '11', '11', '', '2017-02-26', '2017-02-21', '8x0isy3z'),
(3, 14, '1234', '11', '11', '11', '1', '11', '11', '11', '11', '1', '11', '', '2017-02-26', '2017-03-15', '8x0isy3z');

-- --------------------------------------------------------

--
-- Table structure for table `ukuran_kain_kurung`
--

CREATE TABLE IF NOT EXISTS `ukuran_kain_kurung` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `bajuID` int(11) NOT NULL,
  `ID_pelanggan` varchar(6) NOT NULL,
  `ukur_pinggang` varchar(6) DEFAULT NULL,
  `ukur_punggung` varchar(6) DEFAULT NULL,
  `labuh_kain` varchar(6) DEFAULT NULL,
  `lampiran` varchar(255) DEFAULT NULL,
  `tempah_tarikh` date DEFAULT NULL,
  `ambil_tarikh` date DEFAULT NULL,
  `transactioncode` varchar(25) DEFAULT NULL,
  PRIMARY KEY (`id`,`bajuID`,`ID_pelanggan`),
  UNIQUE KEY `id` (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `ukuran_kain_kurung`
--

INSERT INTO `ukuran_kain_kurung` (`id`, `bajuID`, `ID_pelanggan`, `ukur_pinggang`, `ukur_punggung`, `labuh_kain`, `lampiran`, `tempah_tarikh`, `ambil_tarikh`, `transactioncode`) VALUES
(3, 3, '5112', '5', '2', '1', '', '2013-05-18', '0000-00-00', 'rdmz4zva');
