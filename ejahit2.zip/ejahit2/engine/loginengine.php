<?php
include '../include/config.php';

$username=$_POST['username'];
$password=$_POST['password'];


//customer
$sql = "select * from customer where username='$username' and password='$password'";
$result = mysqli_query ($con, $sql);


if (mysqli_num_rows($result) > 0)
{
    echo "berjaya";
   
    header("Location:../user_home.php");
}
else{
       
    print "<script>";
      print "alert('Maklumat Anda Tiada Di Dalam Pangkalan Data Kami. Harap Maklum '); self.location='home.php';"; 
    print "</script>";
	
    }
?>