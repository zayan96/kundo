<?php session_start();

   if(empty($_SESSION['id_pengguna']))
   {  
    header('location:~/../../index.php');
   }
?>


<?php
	include '../dbconnect.php';
?>

<?php


	$staf_id = $_SESSION['id_pengguna'];
	$sql_staf = "SELECT * FROM pengurus
				 WHERE ID_pengurus= '$staf_id'";
					 
	$result_staf = mysql_query($sql_staf) or die('Query failed. ' . mysql_error());
	
	while( $row_staf = mysql_fetch_assoc($result_staf) )
	{
		$id=$row_staf['ID_pengurus'];
		$nama=$row_staf['nama_penuh'];
		$jwtn=$row_staf['jawatan'];
		$almt=$row_staf['alamat'];
		$ic=$row_staf['noKP'];												
		$tel=$row_staf['notel'];								
	}			
	
?>



<?php     
		if (isset($_POST['Submit']))
	    {
			$oldpass	= $_POST["oldPass"];
			$newpass    = $_POST["newPass"];
			$confirmpass	= $_POST["newPass2"];
			$user_id = $_SESSION['id_pengguna'];
			
			$sql2 = "SELECT katalaluan FROM pengurus
					 WHERE ID_pengurus = '$user_id'";
					 
			$result = mysql_query($sql2) or die('Query failed. ' . mysql_error());
			$row = mysql_fetch_array($result, MYSQL_ASSOC);
			$password = $row['katalaluan'];
			
			if ($oldpass == "" && $newpass == "" && $confirmpass == "") 
			{
					$msj="";
			}
			elseif ($oldpass != $password)
			{
					$msj="<font color='red' size='1'>Katalaluan asal tidak tepat!</font>";
			}
			elseif ($newpass != $confirmpass)
			{
					$msj="<font color='red' size='1'>Katalaluan baru tidak sama dengan pengesahan katalaluan!</font>";
			}
			else
			{
				$sql = "UPDATE pengurus SET katalaluan= '$newpass' WHERE ID_pengurus = '$user_id'"; 
				mysql_query($sql) or die(mysql_error());
				
				$msj="<font color='blue' size='1'>Katalaluan berjaya dikemaskini</font>";			
			}	
		}
		else
		{
			$msj="";	
		}
?>


<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml"><head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>e-Tailoring </title>
<link rel="stylesheet" type="text/css" href="../css/bootstrap.css"/>
<link rel="stylesheet" type="text/css" href="../css/stylesheet.css"/>
<link rel="stylesheet" type="text/css" href="../css/sistemkik.css"/>
<script type="text/javascript" src="../js/jquery-1.8.1.js"></script>
<script type="text/javascript" src="../js/bootstrap.js"></script>
<script type="text/javascript" src="../js/validation.js"></script>

<style type="text/css">
body {
	background-image:url(../image/image/background1.jpg);
}

</style>
</head>

<body>
    <div class="container layout_header"><img src="../image/image/logo.png" /></div>              
    <?php include 'navbar.php';?>
    
    <div class="container layoutcontainer" style="height:700px;">
    	<marquee behavior="scroll"><font face="Verdana, Geneva, sans-serif" size="1" color="#0033FF">Selamat Datang Ke e-Tailoring</font></marquee>
		<div class="accordion-group breadcrumb" style="border:solid; border-color:#ccc">
        <legend style="color:#0066CC"><h3>Maklumat Peribadi Penjahit</h3></legend>
        <table width="600" border="0">
          <tr>
            <td width="143" align="right"><label class="control-label" >Id Penjahit:</label></td>
            <td width="447"><label class="control-label" ><b><?php echo $id; ?></b></label></td>
          </tr>
          <tr>
            <td width="143" align="right"><label class="control-label" >Nama :</label></td>
            <td width="447"><label class="control-label" ><b><?php echo $nama; ?></b></label></td>
          </tr>

          
          <tr>
            <td width="143" align="right"><label class="control-label" >Alamat :</label></td>
            <td width="447"><label class="control-label" ><b><?php echo $almt; ?></b></label></td>
          </tr>
          <tr>
            <td align="right"><label class="control-label" >No.Telefon :</label></td>
            <td><label class="control-label" ><b><?php echo $tel; ?></b></label></td>
          </tr>
        </table>
            
        </div>

		<br />
        <div class="accordion-group breadcrumb" style="border:solid; border-color:#ccc">
        <legend style="color:#0066CC"><h3>Tukar Katalaluan</h3></legend>
        <form name="form_staf" id="form_staf" action="" method="post" name="change" autocomplete="off" >
        <table width="600" border="0">
          <tr>
            <td width="112" align="right" nowrap="nowrap"><label class="control-label" >Katalaluan Asal :</label></td>
            <td width="478"><input  class="input-medium" type="text" name="oldPass" id="oldPass" /></td>
          </tr>
          <tr>
            <td align="right" nowrap="nowrap"><label class="control-label" >Katalaluan Baru :</label></td>
            <td><input class="input-medium" type="password" name="newPass" id="newPass" /></td>
          </tr>
          <tr>
            <td align="right" nowrap="nowrap"><label class="control-label" >Pengesahan Katalaluan Baru :</label></td>
            <td><input class="input-medium" type="password" name="newPass2" id="newPass2" /></td>
          </tr>
          <tr >
            <td align="right" nowrap="nowrap">&nbsp;</td>
            <td><?php echo $msj; ?></td>
          </tr>
        </table>
        <div class="form-actions">
               <input name="Submit" type="submit" class="btn btn-primary" id="Submit" value="Hantar" />
               <input name="Reset" type="reset" class="btn btn-danger" id="Submit" value="Semula" />
        </div>
     	</form>
        </div>            
        </div>
    	<br />
        <div class="row span12 footer">
               Copyright © Sistem e-Tailoring  
        </div> 
         
    </div>
    
    
    


          
</body>
</html>

