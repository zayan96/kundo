
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />

<script type="text/javascript">

function logout() {
	var answer = confirm("Anda pasti ingin log keluar?")
	if (answer){
		alert("Sesi anda telah tamat.Sila log masuk semula")
		window.location = "logout.php";
	}
	else{
		
	}
}

</script>

<body>
    <div class="navbar" >
        <div class="navbar-inner">
            <a class="brand" href="index.php"><font size="3" face="Lucida Sans Unicode, Lucida Grande, sans-serif" color="">e-Tailoring</font></a>
            <ul class="nav">
            	<li class="divider-vertical"></li>
                <li class="dropdown">
                  <a href="#" id="drop2" role="button" class="dropdown-toggle" data-toggle="dropdown">Tempahan <b class="caret"></b></a>
                  <ul class="dropdown-menu" role="menu" aria-labelledby="drop2">
                    <li><a tabindex="-1" href="tempahan.php">Terima Tempahan</a></li>
                    <li><a tabindex="-1" href="semak_tempahan.php">Semak Tempahan</a></li>
                    <li><a tabindex="-1" href="senarai_tempahan2.php">Senarai Tempahan</a></li>
                  </ul>
              	</li> 
                <li class="divider-vertical"></li>
                <li><a href="jenis.php">Jenis Jahitan</a></li>
                <li class="divider-vertical"></li>
                <li class="dropdown">
                  <a href="#" id="drop2" role="button" class="dropdown-toggle" data-toggle="dropdown">Pelanggan <b class="caret"></b></a>
                  <ul class="dropdown-menu" role="menu" aria-labelledby="drop2">
                     <li><a tabindex="-1" href="senarai_pelanggan.php">Senarai Pelanggan</a></li>
                    <li><a tabindex="-1" href="daftar_pelanggan.php">Daftar Pelanggan</a></li>
                  </ul>
              	</li> 

             </ul>
             <ul class="nav pull-right">
             <li class="divider-vertical"></li>
             <li class="pull-right" onclick="logout()" ><a href="#">Log Keluar</a></li>
            </ul> 
        </div>
     </div>             
</body>
</html>