<?php

	$sql_cust = "SELECT * FROM pelanggan";								
	$result_cust = mysql_query($sql_cust) or die('Query failed. ' . mysql_error());

?>

<table class="table table-striped table-bordered" id="view">
    <thead>
      <tr style="background-color:#1993E9">
        <th width="20">Id</th>
        <th width="250">Nama Penuh</th>
        <th width="173">Alamat</th>
        <th width="143">No.Telefon</th>
        <th width="100">Tindakan</th>
      </tr>
     </thead>
     <tbody>
		<?php 
        $tmpCount = 1; 
        while($row_pkrja = mysql_fetch_assoc($result_cust)) {?>        
        <tr>
          <td><a href="perinci_pelanggan.php?bil=<?php echo $row_pkrja['id']; ?>"data-toggle="modal" class="btn btn-mini btn-primary"><?php echo $tmpCount; ?></a></td>
          <td><?php echo $row_pkrja['nama_penuh'];; ?></td>
          <td><?php echo $row_pkrja['alamat']; ?></td>
          <td><?php echo $row_pkrja['notel']; ?></td>
          <td>
          	<a href="hapus_pelanggan.php?bil=<?php echo $row_pkrja['id']; ?>"class="btn btn-mini btn-danger">Hapus</a>|  
			<a href="kemas_pelanggan.php?bil=<?php echo $row_pkrja['id']; ?>"class="btn btn-mini btn-primary">Kemas</a>
          </td>
        </tr>     
        <?php $tmpCount ++; }?>  
     
    </tbody>
</table>
