<?php 
		
	$sql1 = "SELECT * FROM pelanggan
			 WHERE ID_pelanggan = $id_plgn";					  							
    $result1 = mysql_query($sql1) or die('Query failed. ' . mysql_error());
	$row1 = mysql_fetch_assoc($result1)
		
?>

     <table class="table table-bordered">
      <tbody>
        <tr>
            <td width="10%">Nama Penuh </td>
            <th width="40%"><?php echo $row1['nama_penuh']?></th>     
        </tr>
       
        <tr>
            <td>Alamat</td>
            <th><?php echo $row1['alamat']?></th>
        </tr>
        <tr>
            <td>No.Telefon </td>
            <th><?php echo $row1['notel']?></th>
        </tr>
       </tbody>
     </table>
     
     <form class="form-horizontal breadcrumb" action="" method="post" id="form_byr" name="form_byr" autocomplete="off">
     <table  width="100%" class=" table breadcrumb " border="0" cellpadding="0">
     	<tr>
        	<td colspan="2">
                <div align="left" class="input-append">
                    <input class="input-medium" id="trans" name="trans" type="text"/> 
                    <input name="carian" class="btn btn-primary" type="submit" value="Kod Transaksi Pelanggan!" /> 
                </div>          
            </td>
        </tr>
        </table>
     </form> 
       
        <?php
		
			if(isset($_POST['carian']) || isset($_GET['trans']))
			{
				
				
				if(isset($_GET['trans']))
				{
					$trans = trim($_GET['trans']);		
				}
				
				if(isset($_POST['carian']))
				{
					$trans = trim($_POST['trans']);		
				}
				
				$id_plgn = 	$id_plgn;
				
				if ($trans <> "")
				{
					
					$sql_list = "SELECT distinct ID_pelanggan,
									id,
							        ukuran_bajukurung.bajuID,
									kategori
							 FROM ukuran_bajukurung,jenis 
							 WHERE ID_pelanggan = '$id_plgn' AND transactioncode = '$trans' AND (ukuran_bajukurung.bajuID=jenis.bajuID)
							 UNION
							 SELECT distinct ID_pelanggan,
							 		id,
							        ukuran_bajumelayu.bajuID,
									kategori
							 FROM ukuran_bajumelayu,jenis
							 WHERE ID_pelanggan = '$id_plgn' AND transactioncode = '$trans' AND (ukuran_bajumelayu.bajuID=jenis.bajuID)
							 UNION
							 SELECT distinct ID_pelanggan,
							 		id,
							        ukuran_jubah.bajuID,
									kategori
							 FROM ukuran_jubah,jenis 
							 WHERE ID_pelanggan = '$id_plgn' AND transactioncode = '$trans' AND (ukuran_jubah.bajuID=jenis.bajuID)
							 UNION
							 SELECT distinct ID_pelanggan,
							 		id,
							        ukuran_kain_kurung.bajuID,
									kategori
							 FROM ukuran_kain_kurung,jenis 
							 WHERE ID_pelanggan = '$id_plgn' AND transactioncode = '$trans' AND (ukuran_kain_kurung.bajuID=jenis.bajuID)";					  							
    		       $result_list = mysql_query($sql_list) or die('Query failed. ' . mysql_error());
				   
				   if (mysql_num_rows($result_list) != 0)
					{						   									  
						require 'senarai_tempahan.php';					   		   				
					}
					else
					{
						 echo "<div class='alert alert-error'><font>Tiada maklumat tempahan ditemui</font></div>";
					}
					
				}
				else
				{
					echo "<div class='alert alert-error'><font>Sila masukkan Kod Transaksi</font></div>";
					
				}
			}	
		?>
       
