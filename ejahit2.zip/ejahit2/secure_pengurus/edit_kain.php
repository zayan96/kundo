<?php

	include '../dbconnect.php';
	
	$jnis_kategori = $_GET['kategori'];
	$id = $_GET['id'];
	$id_plgn = $_GET['id_plgn'];
	$bajuID = $_GET['jnis_ukuran'];
		
	$sql= "SELECT * FROM ukuran_kain_kurung WHERE id = '$id' AND bajuID = '$bajuID' ";						 
	$result = mysql_query($sql) or die('Query failed. ' . mysql_error());
	
	while( $row = mysql_fetch_assoc($result) )
	{
		$ukur_pinggang = $row['ukur_pinggang'];
		$ukur_punggung = $row['ukur_punggung'];
		$labuh_kain = $row['labuh_kain'];									
	}		
?>

<body>

<div align="left" class="accordion-group breadcrumb" style="border:solid; border-color:#ccc">
<legend>Kemaskini Ukuran Kain Kurung</legend>
<form action="" method="post" name="form_kurung" id="form_kurung">
 <table class="table table-striped table-bordered " style="color:#000000; font-family:Arial, Helvetica, sans-serif; 	
      font-size:11px;" cellpadding="0" cellspacing="0" width="441" border="0">
    <tr>
      <th style="background-color:#CCC" nowrap>Ukuran Pinggang</th>
      <td nowrap="nowrap"><input class="input-mini" type="text" name="ukur_pinggang" id="ukur_pinggang" value="<?php echo $ukur_pinggang?>"> inci</td>
      <th style="background-color:#CCC" nowrap>Ukuran Punggung</th>
      <td nowrap="nowrap"><input class="input-mini" type="text" name="ukur_punggung" id="ukur_punggung" value="<?php echo $ukur_punggung?>" /> inci</td>
    </tr>
    <tr>
      <th style="background-color:#CCC" nowrap>Labuh Kain</th>
      <td nowrap="nowrap"><input class="input-mini" type="text" name="labuh_kain" id="labuh_kain" value="<?php echo $labuh_kain?>"> inci</td>
      <th colspan="2"></th>
    </tr>  
    <tr>
      <th style="background-color:#CCC" nowrap>&nbsp;</th>
      <td colspan="3" nowrap="nowrap">
	  <input type="hidden" name="jnis_ukuran"  value="<?php echo $bajuID; ?>" />
      <input type="hidden" name="id"  value="<?php echo $id; ?>" />
      <input class="btn btn-mini btn-primary" type="submit" name="edit_kainkurung" id="simpan" value="Kemaskini">
      <input class="btn btn-mini btn-danger"type="reset" name="button2" id="button2" value="Semula"></td>
    </tr>
  </table>


 </form>   
</div>
</body>
</html>