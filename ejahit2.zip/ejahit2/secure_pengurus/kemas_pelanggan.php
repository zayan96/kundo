<?php session_start();

   if(empty($_SESSION['id_pengguna']))
   {  
    header('location:~/../../index.php');
   }
?>


<?php
	include '../dbconnect.php';
?>

<?php

	if((isset($_GET['bil'])))
	{
		$gcust_id=$_GET['bil'];
				
		$sql_cust="SELECT * FROM pelanggan WHERE id='$gcust_id' ";					
        $result_cust = mysql_query($sql_cust) or die('Query failed. ' . mysql_error());		
		$row_cust = mysql_fetch_array($result_cust);
									
	}	
?>

<?php

	if((isset($_POST['kemas'])))
	{
		$id =$_POST['id'];
		$id_plgn =$_POST['id_pelanggan'];
		$nama = $_POST['nama'];
		$alamat = $_POST['alamat'];
		$notel = $_POST['notel'];
		
		$sql_update = "Update pelanggan set ID_pelanggan='$id_plgn',nama_penuh='$nama',alamat='$alamat',notel='$notel' 
				WHERE id = $id"; 
		mysql_query($sql_update) or die(mysql_error());
						
		print "<script>";
		print " alert('Maklumat berjaya dikemaskini!');
		self.location='senarai_pelanggan.php'"; 
		print "</script>";			
									
	}	
?>


<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml"><head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>e-Tailoring </title>
<link rel="stylesheet" type="text/css" href="../css/bootstrap.css"/>
<link rel="stylesheet" type="text/css" href="../css/stylesheet.css"/>
<link rel="stylesheet" type="text/css" href="../css/sistemkik.css"/>
<script type="text/javascript" src="../js/jquery-1.8.1.js"></script>
<script type="text/javascript" src="../js/bootstrap.js"></script>
<script type="text/javascript" src="../js/validation.js"></script>

<style type="text/css">
body {
	background-image:url(../image/image/background1.jpg);
}

</style>
</head>

<body>
    <div class="container layout_header"><img src="../image/image/logo.png" /></div>              
    <?php include 'navbar.php';?>
    
    <div class="container layoutcontainer" style="height:700px;">
    	<marquee behavior="scroll"><font face="Verdana, Geneva, sans-serif" size="1" color="#0033FF">Selamat Datang Ke e-Tailoring</font></marquee>
		<div class="accordion-group breadcrumb" style="border:solid; border-color:#ccc">
        <legend style="color:#0066CC"><h3>Kemaskini Maklumat Pelanggan</h3></legend>
        <form class="form-horizontal" method="post" name="fsystem" id="fsystem" action="" autocomplete="off" >
        	<div class="control-group">
            	<label class="control-label">ID Pelanggan:</label>
                <div class="controls">
                    <input name="id_pelanggan" id="id_pelanggan" class="input-large" value="<?php echo $row_cust['ID_pelanggan']; ?>"  type="text" />
                <font color="#FF0000">*</font>
                </div>
            </div>
            <div class="control-group">
            	<label class="control-label">Nama:</label>
                <div class="controls">
                    <input name="nama" id="nama" class="input-large" value="<?php echo $row_cust['nama_penuh']; ?>"  type="text" />
                <font color="#FF0000">*</font>
                </div>
            </div>
     
            <div class="control-group">
            	<label class="control-label">Alamat:</label>
                <div class="controls">
                	<textarea name="alamat" id="alamat"  class="input-xlarge" cols="45" rows="3"><?php echo $row_cust['alamat']; ?></textarea>
                	<font color="#FF0000">*</font></div> 
            </div>
            <div class="control-group">
            	<label class="control-label">No.Telefon:</label>
                <div class="controls">
                	<input name="notel" class="input-medium" type="text" value="<?php echo $row_cust['notel']; ?>" id="notel" /> 
                    <font color="#FF0000">*</font>            
                </div>
            </div>

            <div class="control-group">
                <div class="controls">
                    <input type="hidden"  name="id" value="<?php echo $row_cust['id']; ?>" />
                  	<input type="submit" class="btn btn-primary btn-small" name="kemas" id="submit" value="Kemaskini" />
                    <input type="reset" class="btn btn-danger btn-small" name="Reset" id="button" value="Semula" />
                </div>
            </div>
            </form>
             
        </div>
    	<br />
        <div class="row span12 footer">
               Copyright © Sistem e-Tailoring 
        </div> 
         
    </div>
    
    
    


          
</body>
</html>

