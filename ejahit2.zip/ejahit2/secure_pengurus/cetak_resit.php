<?php
	$id_plgn = $_GET['id_plgn'];
	$trans = $_GET['trans'];
	
	include '../dbconnect.php';
	
	$sql_list = "SELECT distinct ukuran_bajukurung.ID_pelanggan,
						ukuran_bajukurung.id,
						ukuran_bajukurung.bajuID,
						pelanggan.nama_penuh,
						pelanggan.alamat,
						pelanggan.notel,
						kategori,
						transactioncode,
						ambil_tarikh
				 FROM ukuran_bajukurung,jenis,pelanggan 
				 WHERE ukuran_bajukurung.ID_pelanggan = '$id_plgn' AND transactioncode = '$trans' AND (ukuran_bajukurung.bajuID=jenis.bajuID) AND (ukuran_bajukurung.ID_pelanggan=pelanggan.ID_pelanggan)
				 UNION
				 SELECT distinct ukuran_bajumelayu.ID_pelanggan,
						ukuran_bajumelayu.id,
						ukuran_bajumelayu.bajuID,
						pelanggan.nama_penuh,
						pelanggan.alamat,
						pelanggan.notel,
						kategori,
						transactioncode,
						ambil_tarikh
				 FROM ukuran_bajumelayu,jenis,pelanggan
				 WHERE ukuran_bajumelayu.ID_pelanggan = '$id_plgn' AND transactioncode = '$trans' AND (ukuran_bajumelayu.bajuID=jenis.bajuID)AND (ukuran_bajumelayu.ID_pelanggan=pelanggan.ID_pelanggan)
				 UNION
				 SELECT distinct ukuran_jubah.ID_pelanggan,
						ukuran_jubah.id,
						ukuran_jubah.bajuID,
						pelanggan.nama_penuh,
						pelanggan.alamat,
						pelanggan.notel,
						kategori,
						transactioncode,
						ambil_tarikh
				 FROM ukuran_jubah,jenis ,pelanggan
				 WHERE ukuran_jubah.ID_pelanggan = '$id_plgn' AND transactioncode = '$trans' AND (ukuran_jubah.bajuID=jenis.bajuID)AND (ukuran_jubah.ID_pelanggan=pelanggan.ID_pelanggan)
				 UNION
				 SELECT distinct ukuran_kain_kurung.ID_pelanggan,
						ukuran_kain_kurung.id,
						ukuran_kain_kurung.bajuID,
						pelanggan.nama_penuh,
						pelanggan.alamat,
						pelanggan.notel,
						kategori,
						transactioncode,
						ambil_tarikh
				 FROM ukuran_kain_kurung,jenis,pelanggan 
				 WHERE ukuran_kain_kurung.ID_pelanggan = '$id_plgn' AND transactioncode = '$trans' AND (ukuran_kain_kurung.bajuID=jenis.bajuID)AND (ukuran_kain_kurung.ID_pelanggan=pelanggan.ID_pelanggan)";					  							
	$result = mysql_query($sql_list) or die('Query failed. ' . mysql_error());
	$row = mysql_fetch_array($result, MYSQL_ASSOC);

    ob_start();
	$content = "
	
	<table width=430 class=table cellpadding=0 table-bordered border=0>
      <tbody>
        <tr>
            <td width=10%>Nama Penuh : </td>
            <th width=40%>".$row['nama_penuh']."</th>     
        </tr>
      
        <tr>
            <td>Alamat :</td>
            <th>".$row['alamat']."</th>
        </tr>
        <tr>
            <td>No.Telefon : </td>
            <th>".$row['notel']."</th>
        </tr>
       </tbody>
     </table>
	 
 
<br><br>";
			  
	$content .= ob_get_clean();

	require_once('../html2pdf_v4.03/html2pdf.class.php');
    $html2pdf = new HTML2PDF('P','A4','en');
    $html2pdf->WriteHTML($content);
    $html2pdf->Output('resit_jahitan1.pdf');

?>