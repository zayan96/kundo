<?php 
		
	$sql1 = "SELECT * FROM pelanggan
			 WHERE ID_pelanggan = $id_plgn";					  							
    $result1 = mysql_query($sql1) or die('Query failed. ' . mysql_error());
	$row1 = mysql_fetch_assoc($result1)
		
?>

     <table class="table table-bordered">
      <tbody>
        <tr>
            <td width="10%">Nama Penuh </td>
            <th width="40%"><?php echo $row1['nama_penuh']?></th>     
        </tr>
      
        <tr>
            <td>Alamat</td>
            <th><?php echo $row1['alamat']?></th>
        </tr>
        <tr>
            <td>No.Telefon </td>
            <th><?php echo $row1['notel']?></th>
        </tr>
       </tbody>
     </table>
     
     
        <?php
		
				$id_plgn = 	$id_plgn;
			
				$sql_list = "SELECT DISTINCT ID_pelanggan,
									transactioncode
							 FROM ukuran_bajukurung,jenis 
							 WHERE ID_pelanggan = '$id_plgn' AND (ukuran_bajukurung.bajuID=jenis.bajuID)
							 UNION
							 SELECT DISTINCT ID_pelanggan,
									transactioncode
							 FROM ukuran_bajumelayu,jenis
							 WHERE ID_pelanggan = '$id_plgn'  AND (ukuran_bajumelayu.bajuID=jenis.bajuID)
							 UNION
							 SELECT DISTINCT ID_pelanggan,
									transactioncode
							 FROM ukuran_jubah,jenis 
							 WHERE ID_pelanggan = '$id_plgn'  AND (ukuran_jubah.bajuID=jenis.bajuID)
							 UNION
							 SELECT DISTINCT ID_pelanggan,
									transactioncode
							 FROM ukuran_kain_kurung,jenis 
							 WHERE ID_pelanggan = '$id_plgn' AND (ukuran_kain_kurung.bajuID=jenis.bajuID)";					  							
			   $result_list = mysql_query($sql_list) or die('Query failed. ' . mysql_error());
			   
			   if (mysql_num_rows($result_list) != 0)
				{						   									  
					require 'senarai_tempah.php';					   		   				
				}
				else
				{
					 echo "<div class='alert alert-error'><font>Tiada maklumat tempahan ditemui</font></div>";
				}
				
				
		
		?>
       
