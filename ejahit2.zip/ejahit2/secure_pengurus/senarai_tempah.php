<?php

	$id_plgn = $id_plgn;
	
	$sql_list = "SELECT DISTINCT ID_pelanggan,
									transactioncode
							 FROM ukuran_bajukurung,jenis 
							 WHERE ID_pelanggan = '$id_plgn' AND (ukuran_bajukurung.bajuID=jenis.bajuID)
							 UNION
							 SELECT DISTINCT ID_pelanggan,
									transactioncode
							 FROM ukuran_bajumelayu,jenis
							 WHERE ID_pelanggan = '$id_plgn'  AND (ukuran_bajumelayu.bajuID=jenis.bajuID)
							 UNION
							 SELECT DISTINCT ID_pelanggan,
									transactioncode
							 FROM ukuran_jubah,jenis 
							 WHERE ID_pelanggan = '$id_plgn'  AND (ukuran_jubah.bajuID=jenis.bajuID)
							 UNION
							 SELECT DISTINCT ID_pelanggan,
									transactioncode
							 FROM ukuran_kain_kurung,jenis 
							 WHERE ID_pelanggan = '$id_plgn' AND (ukuran_kain_kurung.bajuID=jenis.bajuID)";					  							
	$result_list = mysql_query($sql_list) or die('Query failed. ' . mysql_error());

?>

<form action="" method="post" name="form_1" id="form_1">
<table class="table table-striped table-bordered" id="view" style="color:#000000; font-family:Arial, Helvetica, sans-serif;font-size:11px;" cellpadding="0" cellspacing="0">
    <thead>
        <tr style="background-color:#1993E9">
            <th width="20">Bil.</th>
            <th width="143">ID Pelanggan</th>
            <th width="100">Kod Transaksi</th>
        </tr>    
    </thead>
    <tbody>
    <?php 
                    
        $tmpCount = 1; 
        while($row_list = mysql_fetch_assoc($result_list)) {?>        
        <tr>
            <td><a href="" data-toggle="modal" class="btn btn-mini btn-info"><?php echo $tmpCount; ?></a></td>
            <td><?php echo $row_list['ID_pelanggan']; ?></td>
            <td><?php echo $row_list['transactioncode']; ?></td>
       </tr>     
    <?php $tmpCount ++; }?>   
    </tbody>     
 </table>
</form>