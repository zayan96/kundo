<?php session_start();

   if(empty($_SESSION['id_pengguna']))
   {  
    header('location:~/../../index.php');
   }
   
   if (empty($_SESSION['id_plgn']))
   {
	   $_SESSION['id_plgn']=0;
   }
?>



<?php
	include '../dbconnect.php';
?>


<?php
		
	if (isset($_POST['id_plgn']) || isset($_POST['but']) || isset($_GET['id']) || isset($_GET['id_plgn']))
	{		
		if(isset($_POST['id_plgn']))
		{		
			$id_plgn = $_POST['id_plgn'];				
		}
		
		if(isset($_POST['but']))
		{		
			$id_plgn = $_POST['id_plgn'];			
		}	
		
		if(isset($_GET['id']))
		{		
			$id_plgn = $_GET['id_plgn'];	
		}
		
		if(isset($_GET['id_plgn']))
		{		
			$id_plgn = $_GET['id_plgn'];	
		}
				
	}
	else
	{
		$id_plgn = "";
	}	
?>

<?php
		
	if (isset($_POST['jnis_ukuran']) || isset($_GET['jnis_ukuran']))
	{		
		if(isset($_POST['jnis_ukuran']))
		{		
			$jnis_ukuran = $_POST['jnis_ukuran'];				
		}
		
		if(isset($_GET['jnis_ukuran']))
		{		
			$jnis_ukuran = $_GET['jnis_ukuran'];	
		}
		
	}
	else
	{
		$jnis_ukuran = "";
	}	
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml"><head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>e-Tailoring </title>
<link rel="stylesheet" type="text/css" href="../css/bootstrap.css"/>
<link rel="stylesheet" type="text/css" href="../css/bootstrap-datatables.css"/>
<link rel="stylesheet" type="text/css" href="../css/datepicker.css"/>
<link rel="stylesheet" type="text/css" href="../css/stylesheet.css"/>
<link rel="stylesheet" type="text/css" href="../css/sistemkik.css"/>
<link rel="stylesheet" type="text/css" href="../css/templatemo_style.css"/>

<link href="../src/facebox.css" media="screen" rel="stylesheet" type="text/css" />
<script src="../lib/jquery.js" type="text/javascript"></script>
<script src="../src/facebox.js" type="text/javascript"></script>

<style type="text/css">
body {
	background-image:url(../image/image/background1.jpg);
}

</style>

<script type="text/javascript">
jQuery(document).ready(function($) {
  $('a[rel*=facebox]').facebox({
	loadingImage : 'src/loading.gif',

  })
})
</script>

<script type="text/javascript" src="../js/jquery-1.8.1.js"></script>
<script type="text/javascript" src="../js/bootstrap.js"></script>
<script type="text/javascript" src="../js/bootstrap-datepicker.js"></script>
<script type="text/javascript" src="../js/jquery.dataTables.min.js"></script>
<script type="text/javascript" src="../js/bootstrap-datatables.js"></script>
<script type="text/javascript" src="../js/validation.js"></script>

<script>
$(document).ready(function() {
	$('#view').dataTable( {
		"oLanguage": {"sUrl": "../js/dt.txt"},
		"sPaginationType": "bootstrap",
	} );
} );
</script>



<script>
	$(document).ready(function() {
		$("#ambil_tarikh").datepicker( {
			format: 'yyyy-mm-dd'
		});
	});
</script>

<script type="text/javascript" language="javascript">
        function redirect(value) {
            window.location.href = '?id_plgn='+value;
        }
</script>
</head>

<body>
     <div class="container layout_header"><img src="../image/image/logo.png" /></div>         
    <?php include 'navbar.php';?>
    
    <div class="container layoutcontainer" style="height:700px;">
    	<marquee behavior="scroll"><font face="Verdana, Geneva, sans-serif" size="1" color="#0033FF">Selamat Datang ke Sistem e-Tailoring</font></marquee>
		<div class="accordion-group breadcrumb" style="border:solid; border-color:#ccc">
        <legend style="color:#0066CC"><h3>Senarai Tempahan</h3></legend>
        <form class="form-horizontal" action="" method="post" name="form1" id="form1" autocomplete="off"  >
        
            <table class="accordion-group alert-info" width="900px" border="0">
              <tr>
                <td>  
                <br />
                <div class="control-group">
                <label class="control-label"><font color="#000000"><b>Pelanggan :</b></font></label>
                  <div class="controls">
                	<select name="id_plgn" id="id_plgn" style="width:auto" class="required" onchange="redirect(this.value)" >
                    <option  value="" >-- Pilih Pelanggan -- </option>
                     <?php 
		
					$sql_cust="SELECT * FROM pelanggan";	
					$r_cust = mysql_query($sql_cust) or die('Query failed. ' . mysql_error());
							
					while ($row_cust = mysql_fetch_assoc($r_cust)){          
					?>      
					<option value="<?php echo $row_cust['ID_pelanggan'];?>"<?php if(!(strcmp($row_cust['ID_pelanggan'],$id_plgn))){echo "selected=\"selected\""; }?>> 
					<?php echo $row_cust['nama_penuh']." - ".$row_cust['ID_pelanggan']; ?>
					<?php 
					 }
					?>
               		</select>  
                </div> 
                </div>                                                     
                </td>
              </tr>                             
              </table>                
        </form>
		 <?php
    
            if ($id_plgn <> "")
            {	
                if (($_SESSION['id_plgn'] <> $id_plgn))
                {
                    $_SESSION['id_plgn']=$id_plgn;						
                }
                                                                                                    
                require 'maklumat_pelanggan_semak2.php';					
            }
            
         ?>       
        </div>
		<br />
        <div class="row span12 footer">
               Copyright © Sistem e-Tailoring  
        </div> 
         
    </div>      
</body>
</html>

