<?php session_start();

   if(empty($_SESSION['id_pengguna']))
   {  
    header('location:~/../../index.php');
   }
?>


<?php
	include '../dbconnect.php';
?>

<?php

	if(isset($_POST['submit']))
	{		
		$id = $_POST['id'];
		$nama = $_POST['nama'];
		$alamat = $_POST['alamat'];
		$notel = $_POST['notel'];

		
		$sql = "INSERT INTO pelanggan (ID_pelanggan,katalaluan,nama_penuh,alamat,notel,aras) VALUES
				('$id','abc123','$nama','$alamat','$notel','Pelanggan')"; 
		mysql_query($sql) or die(mysql_error());
						
		print "<script>";
		print " alert('Pendaftaran berjaya!');
		self.location='senarai_pelanggan.php'"; 
		print "</script>";				
	}
?>


<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml"><head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>e-Tailoring</title>
<link rel="stylesheet" type="text/css" href="../css/bootstrap.css"/>
<link rel="stylesheet" type="text/css" href="../css/stylesheet.css"/>
<link rel="stylesheet" type="text/css" href="../css/sistemkik.css"/>
<script type="text/javascript" src="../js/jquery-1.8.1.js"></script>
<script type="text/javascript" src="../js/bootstrap.js"></script>
<script type="text/javascript" src="../js/validation.js"></script>

<script src="../lib/jquery.js" type="text/javascript"></script>
<script src="../src/facebox.js" type="text/javascript"></script>
    
<script type="text/javascript">
jQuery(document).ready(function($) {
  $('a[rel*=facebox]').facebox({
	loadingImage : 'src/loading.gif',

  })
})
</script>

<style type="text/css">
body {
	background-image:url(../image/image/background1.jpg);
}

</style>
</head>

<body>
    <div class="container layout_header"><img src="../image/image/logo.png" /></div>              
    <?php include 'navbar.php';?>
    
    <div class="container layoutcontainer" style="height:700px;">
    	<marquee behavior="scroll"><font face="Verdana, Geneva, sans-serif" size="1" color="#0033FF">Selamat Datang Ke Sistem e-Tailoring</font></marquee>
		<div class="accordion-group breadcrumb" style="border:solid; border-color:#ccc">
        <legend style="color:#0066CC"><h3>Daftar Pelanggan</h3></legend>
             
         <form class="form-horizontal" method="post" name="fsystem" id="fsystem" action="" autocomplete="off" >
         	<div class="control-group">
            	<label class="control-label">ID Pelanggan:</label>
                <div class="controls">
                    <input name="id" id="id" class="input-large"  placeholder="ID Pelanggan" type="text" />
                <font color="#FF0000">*</font>
                </div>
            </div>
            <div class="control-group">
            	<label class="control-label">Nama Penuh:</label>
                <div class="controls">
                    <input name="nama" id="nama" class="input-large"  placeholder="Nama" type="text" />
                <font color="#FF0000">*</font>
                </div>
            </div>
    
            <div class="control-group">
            	<label class="control-label">Alamat:</label>
                <div class="controls">
                	<textarea name="alamat" id="alamat"  class="input-xlarge" placeholder="Alamat" cols="45" rows="3"></textarea>
                	<font color="#FF0000">*</font></div> 
            </div>
            
            <div class="control-group">
            	<label class="control-label">No.Telefon:</label>
                <div class="controls">
                	<input name="notel" class="input-medium" type="text" placeholder="No.Telefon" id="notel" /> 
                    <font color="#FF0000">*</font>            
                </div>
            </div>

            <div class="control-group">
                <div class="controls">
                  	<input type="submit" class="btn btn-primary btn-small" name="submit" id="submit" value="Daftar" />
                    <input type="reset" class="btn btn-danger btn-small" name="Reset" id="button" value="Semula" />
                </div>
            </div>
            </form>
        </div>
    	<br />
        <div class="row span12 footer">
               Copyright © Sistem e-Tailoring  
        </div> 
         
    </div>
    
    
    


          
</body>
</html>

