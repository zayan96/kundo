<?php

	if (isset($_GET['bil']))
	{
		$id=$_GET['bil'];
		include '../dbconnect.php';
		
		print ("<SCRIPT LANGUAGE='JavaScript'>
		var answer=window.confirm('Anda pasti ingin hapus maklumat ini?')
		if (answer){
										
			 window.location='hapus_pekerja.php?delete=ya&bil=$id';					 	 
		}
		else
		{				 
			 window.location='senarai_pekerja.php';
		}	
		</SCRIPT>");	
			
	}
	
?>

 <?php
 
 	if (isset($_GET['delete']))
	{		
		$id=$_GET['bil'];		
		$sql = "DELETE FROM pekerja WHERE id='$id'"; 
		mysql_query($sql) or die(mysql_error());
		header("location: senarai_pekerja.php");				
			
	}  
 ?>