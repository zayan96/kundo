<?php session_start();

   if(empty($_SESSION['id_pengguna']))
   {  
    header('location:~/../../index.php');
   }
?>


<?php
	include '../dbconnect.php';
?>





<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml"><head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>e-Tailoring </title>
<link rel="stylesheet" type="text/css" href="../css/bootstrap.css"/>
<link rel="stylesheet" type="text/css" href="../css/bootstrap-datatables.css"/>
<link rel="stylesheet" type="text/css" href="../css/stylesheet.css"/>
<link rel="stylesheet" type="text/css" href="../css/sistemkik.css"/>

<script type="text/javascript" src="../js/jquery-1.8.1.js"></script>
<script type="text/javascript" src="../js/bootstrap.js"></script>
<script type="text/javascript" src="../js/jquery.dataTables.min.js"></script>
<script type="text/javascript" src="../js/bootstrap-datatables.js"></script>
<script type="text/javascript" src="../js/validation.js"></script>

<style type="text/css">
body {
	background-image:url(../image/image/background1.jpg);
}

</style>

<script type="text/javascript">
	
	$(document).ready(function() {		
	$('[data-toggle="modal"]').click(function(e) 
	{
		e.preventDefault();
		var url = $(this).attr('href');
		if (url.indexOf('#') == 0) 
		{
			$(url).modal('open');
		}
		else 
		{
		  $.get(url, function(data) 
		  {
			$('<div class="modal hide fade" aria-hidden="true" style="width:700px; height:auto; margin:-250px 0 0 -350px;">' + data + '</div>').modal();
		   }).success(function() 
		   {
				$('input:text:visible:first').focus(); 
		   });
		}
	});
});
		
</script>

<script>
$(document).ready(function() {
	$('#view').dataTable( {
		"oLanguage": {"sUrl": "../js/dt.txt"},
		"sPaginationType": "bootstrap",
	} );
} );
</script>
</head>

<body>
    <div class="container layout_header">
          <img src="../image/image/logo.png" alt="">
    </div>              
    <?php include 'navbar.php';?>
    
    <div class="container layoutcontainer" style="height:700px;">
    	<marquee behavior="scroll"><font face="Verdana, Geneva, sans-serif" size="1" color="#0033FF">Selamat Datang Ke Sistem e-Tailoring</font></marquee>
		<div class="accordion-group breadcrumb" style="border:solid; border-color:#ccc">
        <legend style="color:#0066CC"><h3>Senarai Pelanggan</h3></legend>
        <?php
																	
				$sql_cust = " SELECT * FROM pelanggan";								
				$result_cust = mysql_query($sql_cust) or die('Query failed. ' . mysql_error());
								
				if (mysql_num_rows($result_cust) != 0)
				{						   									  
					require 'list_pelanggan.php';					   		   				
				}
				else
				{
					echo "<div class='alert alert-error'><font>Harap maaf!..Tiada maklumat pelanggan</font></div>";
				}
						 	 				
 		    ?> 
       
        
        </div>
        <div class="row span12 footer">
               Copyright © Sistem e-Tailoring
        </div> 
         
    </div>
    
    
    


          
</body>
</html>

