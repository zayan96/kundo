<?php

	$sql_jenis = "SELECT * FROM jenis ORDER BY kategori ASC";								
	$result_jenis = mysql_query($sql_jenis) or die('Query failed. ' . mysql_error());

?>

<table class="table table-striped table-bordered" id="view">
    <thead>
      <tr style="background-color:#1993E9">
        <th width="20">Id</th>
        <th width="220">Kategori</th>
        <th width="200">Material</th>
        <th width="50">Tindakan</th>
      </tr>
     </thead>
     <tbody>
		<?php 
        $tmpCount = 1; 
        while($row_jenis = mysql_fetch_assoc($result_jenis)) {?>        
        <tr>
          <td><a rel="facebox" href="lakaran.php?bil=<?php echo $row_jenis['bajuID']; ?>" class="btn btn-mini btn-primary"><?php echo $tmpCount; ?></a></td>
          <td><?php echo $row_jenis['kategori'];; ?></td>
          <td><?php echo $row_jenis['material']; ?></td>
          <td><a href="hapus_jenis.php?bil=<?php echo $row_jenis['bajuID']; ?>"class="btn btn-mini btn-danger">Hapus</a></td>
        </tr>     
        <?php $tmpCount ++; }?>      
    </tbody>
</table>
