<?php session_start();

   if(empty($_SESSION['id_pengguna']))
   {  
    header('location:~/../../index.php');
   }
?>


<?php
	include '../dbconnect.php';
?>

<?php

	if(isset($_POST['submit']))
	{		
		
	 $target = "../jenis/"; 
	 $target = $target . basename( $_FILES['uploaded']['name']) ; 
	 $ok=1; 

	
	  if (file_exists("../jenis/" . $_FILES['uploaded']['name']))
	  {
		$image=basename( $_FILES['uploaded']['name']) ;
	  }
	  else
	  {
		 $image=basename( $_FILES['uploaded']['name']) ;
		 if(move_uploaded_file($_FILES['uploaded']['tmp_name'], $target)) 
		 { 
			 
		 } 
		 else 
		 { 
			echo "Sorry, there was a problem uploading your file."; 
		 } 
	  }	 
	
	 $kategori = $_POST['kategori'];
	 $material = $_POST['material'];

	 $sql = "INSERT INTO jenis (kategori,material,image) VALUES ('$kategori','$material','$image')"; 
	 mysql_query($sql) or die(mysql_error());
					
	 print "<script>";
	 print " alert('Maklumat berjaya disimpan!');
	 self.location='jenis.php'"; 
	 print "</script>";				
	}
?>


<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml"><head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>e-Tailoring </title>
<link rel="stylesheet" type="text/css" href="../css/bootstrap.css"/>
<link rel="stylesheet" type="text/css" href="../css/sistemkik.css"/>
<link rel="stylesheet" type="text/css" href="../css/bootstrap-datatables.css"/>

<link href="../src/facebox.css" media="screen" rel="stylesheet" type="text/css" />
<script src="../lib/jquery.js" type="text/javascript"></script>
<script src="../src/facebox.js" type="text/javascript"></script>

<script type="text/javascript">

jQuery(document).ready(function($) {
  $('a[rel*=facebox]').facebox({
	loadingImage : '../src/loading.gif',
	closeImage   : '../src/closelabel.png'
  })
})
</script>

<script type="text/javascript" src="../js/jquery-1.8.1.js"></script>
<script type="text/javascript" src="../js/bootstrap.js"></script>
<script type="text/javascript" src="../js/jquery.dataTables.min.js"></script>
<script type="text/javascript" src="../js/bootstrap-datatables.js"></script>
<script type="text/javascript" src="../js/validation.js"></script>


<script>
$(document).ready(function() {
	$('#view').dataTable( {
		"oLanguage": {"sUrl": "../js/dt.txt"},
		"sPaginationType": "bootstrap",
	} );
} );
</script>

<style type="text/css">
body {
	background-image:url(../image/image/background1.jpg);
}

</style>


</head>

<body>
    <div class="container layout_header"><img src="../image/image/logo.png" /></div>              
    <?php include 'navbar.php';?>
    
    <div class="container layoutcontainer" style="height:700px;">
    	<marquee behavior="scroll"><font face="Verdana, Geneva, sans-serif" size="1" color="#0033FF">Selamat Datang Ke Sistem e-Tailoring</font></marquee>
		<div class="accordion-group breadcrumb" style="border:solid; border-color:#ccc">
        <legend style="color:#0066CC"><h3>Jenis Pakaian</h3></legend>
             
         <form enctype="multipart/form-data" class="form-horizontal" method="post" name="fsystem" id="fsystem" action="" autocomplete="off" >
         	<div class="control-group">
            	<label class="control-label">Kategori:</label>
                <div class="controls">
                	<select name="kategori" id="kategori">
                    	<option value="" selected="selected">Pilih Kategori</option>
                    	<option value="Baju Melayu">Baju Melayu</option>
                        <option value="Baju Kurung">Baju Kurung</option>
                        <option value="Kain Kurung">Kain Kurung</option>  
                        <option value="Jubah">Jubah</option>
                                
                    </select>
                <font color="#FF0000">*</font>
                </div>
            </div>
            <div class="control-group">
            	<label class="control-label">Material:</label>
                <div class="controls">
                    <input name="material" id="material" class="input-large"  placeholder="Material" type="text" />
                <font color="#FF0000">*</font>
                </div>
            </div>
            <div class="control-group">
            	<label class="control-label">Lakaran/Gambar:</label>
                <div class="controls">
                    <input class="input-file" id="uploaded" name="uploaded" type="file" />
                </div>
            </div>
            
            <div class="control-group">
                <div class="controls">
                  	<input type="submit" class="btn btn-primary btn-small" name="submit" id="submit" value="Daftar Jenis" />
                    <input type="reset" class="btn btn-danger btn-small" name="Reset" id="button" value="Semula" />
                </div>
            </div>
            </form>
        </div>
    	<br />
        <div class="accordion-group breadcrumb" style="border:solid; border-color:#ccc">     
        	<legend style="color:#0066CC"><h3>Senarai Jenis Pakaian</h3></legend>
            <?php
																	
				$sql_jenis = " SELECT * FROM jenis";								
				$result_jenis = mysql_query($sql_jenis) or die('Query failed. ' . mysql_error());
								
				if (mysql_num_rows($result_jenis) != 0)
				{						   									  
					require 'list_jenis.php';					   		   				
				}
				else
				{
					echo "<div class='alert alert-error'><font>Harap maaf!..Tiada maklumat jenis pakaian</font></div>";
				}
						 	 				
 		    ?> 
        
        </div>
        <br />
        <div class="row span12 footer">
               Copyright © Sistem e-Tailoring 
        </div> 
         
    </div>
    
    
    


          
</body>
</html>

