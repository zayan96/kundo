
<body>

  <table class="table table-striped table-bordered " style="color:#000000; font-family:Arial, Helvetica, sans-serif; 	
      font-size:11px;" cellpadding="0" cellspacing="0" width="441" border="0">
    <tr>
      <th style="background-color:#CCC" nowrap>Labuh Lengan</th>
      <td nowrap="nowrap"><input class="input-mini" type="text" name="labuh_lengan" id="labuh_lengan"> inci</td>
      <th style="background-color:#CCC" nowrap>Panjang Baju</th>
      <td nowrap="nowrap"><input class="input-mini" type="text" name="panjang_baju" id="panjang_baju" /> inci</td>
    </tr>
    <tr>
      <th style="background-color:#CCC" nowrap>Lilit Leher</th>
      <td nowrap="nowrap"><input class="input-mini" type="text" name="lilit_leher" id="lilit_leher"> inci</td>
      <th style="background-color:#CCC" nowrap>Lilit Dada</th>
      <td nowrap="nowrap"><input class="input-mini" type="text" name="lilit_dada" id="lilit_dada" /> inci</td>
    </tr>
    <tr>
      <th style="background-color:#CCC" nowrap>Tarikh Dijangka Ambil</th>
      <td colspan="3" nowrap="nowrap"><input class="input-small" type="text" name="ambil_tarikh" id="ambil_tarikh"></td>
    </tr>
    <tr>
      <th style="background-color:#CCC" nowrap>Lampiran</th>
      <td colspan="3" nowrap="nowrap"> <input class="input-file" id="uploaded" name="uploaded" type="file" /></td>
    </tr>    
    <tr>
      <th style="background-color:#CCC" nowrap>&nbsp;</th>
      <td colspan="3" nowrap="nowrap">
      <input type="hidden" name="jnis_ukuran"  value="<?php echo $jnis_ukuran; ?>" />
      <input class="btn btn-mini btn-primary" type="submit" name="simpan_bajumelayu" id="simpan" value="Simpan Ukuran">
      <input class="btn btn-mini btn-danger"type="reset" name="button2" id="button2" value="Semula"></td>
    </tr>
  </table>

</body>

