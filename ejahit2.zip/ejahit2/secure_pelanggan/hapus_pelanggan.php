<?php

	if (isset($_GET['bil']))
	{
		$id=$_GET['bil'];
		include '../dbconnect.php';
		
		print ("<SCRIPT LANGUAGE='JavaScript'>
		var answer=window.confirm('Anda pasti ingin hapus maklumat ini?')
		if (answer){
										
			 window.location='hapus_pelanggan.php?delete=ya&bil=$id';					 	 
		}
		else
		{				 
			 window.location='senarai_pelanggan.php';
		}	
		</SCRIPT>");	
			
	}
	
?>

 <?php
 
 	if (isset($_GET['delete']))
	{		
		$id=$_GET['bil'];		
		$sql = "DELETE FROM pelanggan WHERE id='$id'"; 
		mysql_query($sql) or die(mysql_error());
		header("location: senarai_pelanggan.php");				
			
	}  
 ?>