<?php
	include '../dbconnect.php';	
?>

<?php

	if((isset($_GET['bil'])))
	{
		$gpkrja_id=$_GET['bil'];
				
		$sql_pkrja="SELECT * FROM pelanggan WHERE id='$gpkrja_id' ";					
        $result_pkrja = mysql_query($sql_pkrja) or die('Query failed. ' . mysql_error());		
		$row_pkrja = mysql_fetch_array($result_pkrja);
									
	}	
?>

   <!--Skrin Kemaskini Maklumat Potongan-->
  	<div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
        <h3 id="myModalLabel">Maklumat Perinci Pelanggan</h3>
    </div>
    
    <div class="modal-body"> 
    
    <form name="form_kemasptgn" id="form_kemasptgn" style="margin-left:100px;" class="form-horizontal" action="" method="POST" autocomplete="off">
        <p >
        <div class="control-group">
            <label class="control-label">ID Pelanggan :</label>
            <div class="controls">    
            <label style="text-align:left; white-space:nowrap" class="control-label"><b><font color="#0066CC"><?php echo $row_pkrja['ID_pelanggan']; ?></font></b></label>                        
            </div>
        </div>
        <div class="control-group">
            <label class="control-label">Nama :</label>
            <div class="controls">    
            <label style="text-align:left; white-space:nowrap" class="control-label"><b><font color="#0066CC"><?php echo $row_pkrja['nama_penuh']; ?></font></b></label>                        
            </div>
        </div>

        <div class="control-group">
            <label class="control-label">Alamat :</label>
            <div class="controls">
            <label style=" text-align:left" class="control-label"><b><font color="#0066CC"><?php echo $row_pkrja['alamat']; ?></font></b></label>
            </div>
		</div>
        <div class="control-group">
            <label class="control-label">No.Telefon :</label>
            <div class="controls">
            <label style=" text-align:left" class="control-label"><b><font color="#0066CC"><?php echo $row_pkrja['notel']; ?></font></b></label>
            </div>
		</div>  
        </p>
    </form>
    </div>   
    <div class="modal-footer">
	<button class="btn" data-dismiss="modal" aria-hidden="true">Tutup</button>
	</div>
