<?php session_start();

   if(empty($_SESSION['id_pengguna']))
   {  
    header('location:~/../../index.php');
   }
   
    if (empty($_SESSION['id_plgn']))
   {
	   $_SESSION['id_plgn']=0;
   }
?>



<?php
	include '../dbconnect.php';
?>

<?php

	if(isset($_POST['simpan_bajukurung']))
	{
		$target = "../lampiran/"; 
		$target = $target . basename( $_FILES['uploaded']['name']) ; 
		$ok=1; 
		
	  	if (file_exists("../lampiran/" . $_FILES['uploaded']['name']))
	  	{
			$image=basename( $_FILES['uploaded']['name']) ;
	  	}
	  	else
	  	{
			$image=basename( $_FILES['uploaded']['name']) ;
			if(move_uploaded_file($_FILES['uploaded']['tmp_name'], $target)) { 
				 
			} 
			else 
			{ 
				echo "Sorry, there was a problem uploading your file."; 
			} 
		}	 
		
		$id_plgn = $_POST['id_plgn'];
		$bajuID = $_POST['jnis_ukuran'];
		$bukaan_tangan = $_POST['bukaan_tangan'];
		$lilit_ketiak = $_POST['lilit_ketiak'];
		$panjang_baju = $_POST['panjang_baju'];
		$ukuran_bahu = $_POST['ukuran_bahu'];
		$ukuran_dada = $_POST['ukuran_dada'];
		$ukuran_pinggul = $_POST['ukuran_pinggul'];
		$transactioncode = $_POST['transactioncode'];
		$ambil_tarikh = $_POST['ambil_tarikh'];
		$tarikh_tempah = date('Y-m-d');
		
		$sql_kurung = "INSERT INTO ukuran_bajukurung (bajuID,ID_pelanggan,bukaan_tangan,lilit_ketiak,panjang_baju,ukuran_bahu,ukuran_dada,ukuran_pinggul,tempah_tarikh,ambil_tarikh,lampiran,transactioncode) VALUES 
					  ('$bajuID','$id_plgn','$bukaan_tangan','$lilit_ketiak','$panjang_baju','$ukuran_bahu','$ukuran_dada','$ukuran_pinggul','$tarikh_tempah','$ambil_tarikh','$image','$transactioncode')"; 
	    mysql_query($sql_kurung) or die(mysql_error());	
		
		print "<script type='text/javascript'>self.location='tempahan.php?id_plgn=$id_plgn&jnis_ukuran=$bajuID';</script>";	
		
	}
?>

<?php

	if(isset($_POST['edit_bajukurung']))
	{
		$id = $_POST['id'];
		$bajuID = $_POST['jnis_ukuran'];
		$bukaan_tangan = $_POST['bukaan_tangan'];
		$lilit_ketiak = $_POST['lilit_ketiak'];
		$panjang_baju = $_POST['panjang_baju'];
		$ukuran_bahu = $_POST['ukuran_bahu'];
		$ukuran_dada = $_POST['ukuran_dada'];
		$ukuran_pinggul = $_POST['ukuran_pinggul'];
		
		$sql_kurung = "UPDATE ukuran_bajukurung SET bukaan_tangan='$bukaan_tangan',lilit_ketiak='$lilit_ketiak',panjang_baju='$panjang_baju',ukuran_bahu='$ukuran_bahu',ukuran_dada='$ukuran_dada',ukuran_pinggul='$ukuran_pinggul' 
					   WHERE id ='$id' AND bajuID ='$bajuID'"; 
	    mysql_query($sql_kurung) or die(mysql_error());						
	}
?>

<?php

	if(isset($_POST['simpan_bajumelayu']))
	{
		$target = "../lampiran/"; 
		$target = $target . basename( $_FILES['uploaded']['name']) ; 
		$ok=1; 
		
	  	if (file_exists("../lampiran/" . $_FILES['uploaded']['name']))
	  	{
			$image=basename( $_FILES['uploaded']['name']) ;
	  	}
	  	else
	  	{
			$image=basename( $_FILES['uploaded']['name']) ;
			if(move_uploaded_file($_FILES['uploaded']['tmp_name'], $target)) { 
				 
			} 
			else 
			{ 
				echo "Sorry, there was a problem uploading your file."; 
			} 
		}	 
		
		$id_plgn = $_POST['id_plgn'];
		$bajuID = $_POST['jnis_ukuran'];
		$labuh_lengan = $_POST['labuh_lengan'];
		$panjang_baju = $_POST['panjang_baju'];
		$lilit_leher = $_POST['lilit_leher'];
		$lilit_dada = $_POST['lilit_dada'];
		$transactioncode = $_POST['transactioncode'];
		$ambil_tarikh = $_POST['ambil_tarikh'];
		$tarikh_tempah = date('Y-m-d');
		
		$sql_melayu = "INSERT INTO ukuran_bajumelayu (bajuID,ID_pelanggan,labuh_lengan,panjang_baju,lilit_leher,lilit_dada,tempah_tarikh,ambil_tarikh,lampiran,transactioncode) VALUES 
					  ('$bajuID','$id_plgn','$labuh_lengan','$panjang_baju','$lilit_leher','$lilit_dada','$tarikh_tempah','$ambil_tarikh','$image','$transactioncode')"; 
	    mysql_query($sql_melayu) or die(mysql_error());	
		
		print "<script type='text/javascript'>self.location='tempahan.php?id_plgn=$id_plgn&jnis_ukuran=$bajuID';</script>";	
		
	}
?>

<?php

	if(isset($_POST['edit_bajumelayu']))
	{
		$id = $_POST['id'];
		$bajuID = $_POST['jnis_ukuran'];
		$labuh_lengan = $_POST['labuh_lengan'];
		$panjang_baju = $_POST['panjang_baju'];
		$lilit_leher = $_POST['lilit_leher'];
		$lilit_dada = $_POST['lilit_dada'];

		
		$sql_melayu = "UPDATE ukuran_bajumelayu SET labuh_lengan='$labuh_lengan',panjang_baju='$panjang_baju',lilit_leher='$lilit_leher',lilit_dada='$lilit_dada' 
					   WHERE id ='$id' AND bajuID ='$bajuID'"; 
	    mysql_query($sql_melayu) or die(mysql_error());						
	}
?>


<?php

	if(isset($_POST['simpan_kainkurung']))
	{
		$target = "../lampiran/"; 
		$target = $target . basename( $_FILES['uploaded']['name']) ; 
		$ok=1; 
		
	  	if (file_exists("../lampiran/" . $_FILES['uploaded']['name']))
	  	{
			$image=basename( $_FILES['uploaded']['name']) ;
	  	}
	  	else
	  	{
			$image=basename( $_FILES['uploaded']['name']) ;
			if(move_uploaded_file($_FILES['uploaded']['tmp_name'], $target)) { 
				 
			} 
			else 
			{ 
				echo "Sorry, there was a problem uploading your file."; 
			} 
		}	 
		
		$id_plgn = $_POST['id_plgn'];
		$bajuID = $_POST['jnis_ukuran'];
		$ukur_pinggang = $_POST['ukur_pinggang'];
		$ukur_punggung = $_POST['ukur_punggung'];
		$labuh_kain = $_POST['labuh_kain'];
		$transactioncode = $_POST['transactioncode'];
		$ambil_tarikh = $_POST['ambil_tarikh'];
		$tarikh_tempah = date('Y-m-d');
		
		$sql_kkurung = "INSERT INTO ukuran_kain_kurung (bajuID,ID_pelanggan,ukur_pinggang,ukur_punggung,labuh_kain,tempah_tarikh,ambil_tarikh,lampiran,transactioncode) VALUES 
					  ('$bajuID','$id_plgn','$ukur_pinggang','$ukur_punggung','$labuh_kain','$tarikh_tempah','$ambil_tarikh','$image','$transactioncode')"; 
	    mysql_query($sql_kkurung) or die(mysql_error());
		
		print "<script type='text/javascript'>self.location='tempahan.php?id_plgn=$id_plgn&jnis_ukuran=$bajuID';</script>";		
		
	}
?>

<?php

	if(isset($_POST['edit_kainkurung']))
	{
		$id = $_POST['id'];
		$bajuID = $_POST['jnis_ukuran'];
		$ukur_pinggang = $_POST['ukur_pinggang'];
		$ukur_punggung = $_POST['ukur_punggung'];
		$labuh_kain = $_POST['labuh_kain'];
		
		$sql_kkurung = "UPDATE ukuran_kain_kurung SET ukur_pinggang='$ukur_pinggang',ukur_punggung='$ukur_punggung',labuh_kain='$labuh_kain' 
						WHERE id ='$id' AND bajuID ='$bajuID'"; 
	    mysql_query($sql_kkurung) or die(mysql_error());						
	}
?>

<?php

	if(isset($_POST['simpan_jubah']))
	{
		$target = "../lampiran/"; 
		$target = $target . basename( $_FILES['uploaded']['name']) ; 
		$ok=1; 
		
	  	if (file_exists("../lampiran/" . $_FILES['uploaded']['name']))
	  	{
			$image=basename( $_FILES['uploaded']['name']) ;
	  	}
	  	else
	  	{
			$image=basename( $_FILES['uploaded']['name']) ;
			if(move_uploaded_file($_FILES['uploaded']['tmp_name'], $target)) { 
				 
			} 
			else 
			{ 
				echo "Sorry, there was a problem uploading your file."; 
			} 
		}	 
		
		$id_plgn = $_POST['id_plgn'];
		$bajuID = $_POST['jnis_ukuran'];
		$lilit_leher = $_POST['lilit_leher'];
		$lebar_bahu = $_POST['lebar_bahu'];
		$lebar_punggung = $_POST['lebar_punggung'];
		$lebar_lengan = $_POST['lebar_lengan'];
		$lebar_pinggang = $_POST['lebar_pinggang'];
		$lebar_dada = $_POST['lebar_dada'];		
		$lebar_kain = $_POST['lebar_kain'];
		$panjang_tangan = $_POST['panjang_tangan'];
		$panjang_badan = $_POST['panjang_badan'];
		$panjang_baju = $_POST['panjang_baju'];
		$transactioncode = $_POST['transactioncode'];
		$ambil_tarikh = $_POST['ambil_tarikh'];
		$tarikh_tempah = date('Y-m-d');
		
		$sql_jubah = "INSERT INTO ukuran_jubah(bajuID,ID_pelanggan,lilit_leher,lebar_bahu,lebar_punggung,lebar_lengan,lebar_pinggang,lebar_dada,lebar_kain,panjang_tangan,panjang_badan,panjang_baju,tempah_tarikh,ambil_tarikh,lampiran,transactioncode) VALUES 
					  ('$bajuID','$id_plgn','$lilit_leher','$lebar_bahu','$lebar_punggung','$lebar_lengan','$lebar_pinggang','$lebar_dada','$lebar_kain','$panjang_tangan','$panjang_badan','$panjang_baju','$tarikh_tempah','$ambil_tarikh','$image','$transactioncode')"; 
	    mysql_query($sql_jubah) or die(mysql_error());	
		
		print "<script type='text/javascript'>self.location='tempahan.php?id_plgn=$id_plgn&jnis_ukuran=$bajuID';</script>";	
		
	}
?>

<?php

	if(isset($_POST['edit_jubah']))
	{
		$id = $_POST['id'];
		$bajuID = $_POST['jnis_ukuran'];
		$lilit_leher = $_POST['lilit_leher'];
		$lebar_bahu = $_POST['lebar_bahu'];
		$lebar_punggung = $_POST['lebar_punggung'];
		$lebar_lengan = $_POST['lebar_lengan'];
		$lebar_pinggang = $_POST['lebar_pinggang'];
		$lebar_dada = $_POST['lebar_dada'];		
		$lebar_kain = $_POST['lebar_kain'];
		$panjang_tangan = $_POST['panjang_tangan'];
		$panjang_badan = $_POST['panjang_badan'];
		$panjang_baju = $_POST['panjang_baju'];
		
		$sql_jubah = "UPDATE ukuran_jubah SET lilit_leher='$lilit_leher',lebar_bahu='$lebar_bahu',lebar_punggung='$lebar_punggung',lebar_lengan='$lebar_lengan',lebar_pinggang='$lebar_pinggang',lebar_dada='$lebar_dada', 
					 lebar_kain='$lebar_kain',panjang_tangan='$panjang_tangan',panjang_badan='$panjang_badan',panjang_baju='$panjang_baju'  WHERE id ='$id' AND bajuID ='$bajuID'"; 
	    mysql_query($sql_jubah) or die(mysql_error());						
	}
?>

<?php
		
	if (isset($_POST['id_plgn']) || isset($_POST['but']) || isset($_GET['id']) || isset($_GET['id_plgn']))
	{		
		if(isset($_POST['id_plgn']))
		{		
			$id_plgn = $_POST['id_plgn'];				
		}
		
		if(isset($_POST['but']))
		{		
			$id_plgn = $_POST['id_plgn'];			
		}	
		
		if(isset($_GET['id']))
		{		
			$id_plgn = $_GET['id_plgn'];	
		}
		
		if(isset($_GET['id_plgn']))
		{		
			$id_plgn = $_GET['id_plgn'];	
		}
				
	}
	else
	{
		$id_plgn = "";
	}	
?>

<?php
		
	if (isset($_POST['jnis_ukuran']) || isset($_GET['jnis_ukuran']))
	{		
		if(isset($_POST['jnis_ukuran']))
		{		
			$jnis_ukuran = $_POST['jnis_ukuran'];				
		}
		
		if(isset($_GET['jnis_ukuran']))
		{		
			$jnis_ukuran = $_GET['jnis_ukuran'];	
		}
		
	}
	else
	{
		$jnis_ukuran = "";
	}	
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml"><head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>e-Tailoring </title>
<link rel="stylesheet" type="text/css" href="../css/bootstrap.css"/>
<link rel="stylesheet" type="text/css" href="../css/bootstrap-datatables.css"/>
<link rel="stylesheet" type="text/css" href="../css/datepicker.css"/>
<link rel="stylesheet" type="text/css" href="../css/stylesheet.css"/>
<link rel="stylesheet" type="text/css" href="../css/sistemkik.css"/>
<link rel="stylesheet" type="text/css" href="../css/templatemo_style.css"/>

<link href="../src/facebox.css" media="screen" rel="stylesheet" type="text/css" />
<script src="../lib/jquery.js" type="text/javascript"></script>
<script src="../src/facebox.js" type="text/javascript"></script>

<style type="text/css">
body {
	background-image:url(../image/image/background1.jpg);
}

</style>

<script type="text/javascript">
jQuery(document).ready(function($) {
  $('a[rel*=facebox]').facebox({
	loadingImage : 'src/loading.gif',

  })
})
</script>

<script type="text/javascript" src="../js/jquery-1.8.1.js"></script>
<script type="text/javascript" src="../js/bootstrap.js"></script>
<script type="text/javascript" src="../js/bootstrap-datepicker.js"></script>
<script type="text/javascript" src="../js/jquery.dataTables.min.js"></script>
<script type="text/javascript" src="../js/bootstrap-datatables.js"></script>
<script type="text/javascript" src="../js/validation.js"></script>

<script>
$(document).ready(function() {
	$('#view').dataTable( {
		"oLanguage": {"sUrl": "../js/dt.txt"},
		"sPaginationType": "bootstrap",
	} );
} );
</script>



<script>
	$(document).ready(function() {
		$("#ambil_tarikh").datepicker( {
			format: 'yyyy-mm-dd'
		});
	});
</script>

<script type="text/javascript" language="javascript">
        function redirect(value) {
            window.location.href = '?id_plgn='+value;
        }
</script>
</head>

<body>
    <div class="container layout_header"><img src="../image/image/logo.png" /></div>              
    <?php include 'navbar.php';?>
    
    <div class="container layoutcontainer" style="height:700px;">
    	<marquee behavior="scroll"><font face="Verdana, Geneva, sans-serif" size="1" color="#0033FF">Selamat Datang Ke Sistem e-Tailoring</font></marquee>
		<div class="accordion-group breadcrumb" style="border:solid; border-color:#ccc">
        <legend style="color:#0066CC"><h3>Buat Tempahan</h3></legend>
        <form class="form-horizontal" action="" method="post" name="form1" id="form1" autocomplete="off"  >
        
            <table class="accordion-group alert-info" width="900px" border="0">
              <tr>
                <td>  
                <br />
                <div class="control-group">
                <label class="control-label"><font color="#000000"><b>Pelanggan :</b></font></label>
                  <div class="controls">
                	<select name="id_plgn" id="id_plgn" style="width:auto" class="required" onchange="redirect(this.value)" >
                    <option  value="" >-- Pilih Pelanggan -- </option>
                     <?php 
		
					$sql_cust="SELECT * FROM pelanggan";	
					$r_cust = mysql_query($sql_cust) or die('Query failed. ' . mysql_error());
							
					while ($row_cust = mysql_fetch_assoc($r_cust)){          
					?>      
					<option value="<?php echo $row_cust['ID_pelanggan'];?>"<?php if(!(strcmp($row_cust['ID_pelanggan'],$id_plgn))){echo "selected=\"selected\""; }?>> 
					<?php echo $row_cust['nama_penuh']." - ".$row_cust['ID_pelanggan']; ?>
					<?php 
					 }
					?>
               		</select>  
                </div> 
                </div>                                                     
                </td>
              </tr>                             
              </table>   
                    
            </form>
             <?php
		
				if ($id_plgn <> "")
				{																						
					if (($_SESSION['id_plgn'] <> $id_plgn))
					{
						$_SESSION['id_plgn']=$id_plgn;
						
						function createRandomPassword() {
						$chars = "abcdefghijkmnopqrstuvwxyz023456789";
						srand((double)microtime()*1000000);
						$i = 0;
						$pass = '' ;
						
						while ($i <= 7) {
					
							$num = rand() % 33;
							$tmp = substr($chars, $num, 1);
							$pass = $pass . $tmp;
							$i++;
						}
						return $pass;
						}
						$confirmation = createRandomPassword();
						$_SESSION['Transcode'] = $confirmation;						
					}
					
					require 'maklumat_pelanggan.php';					
				}
				
 			 ?>  
            
        
        </div>
		<br />
        <div class="row span12 footer">
               Copyright © Sistem e-Tailoring 
        </div> 
         
    </div>      
</body>
</html>

