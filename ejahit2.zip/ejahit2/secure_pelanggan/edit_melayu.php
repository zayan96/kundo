<?php

	include '../dbconnect.php';
	
	$jnis_kategori = $_GET['kategori'];
	$id = $_GET['id'];
	$id_plgn = $_GET['id_plgn'];
	$bajuID = $_GET['jnis_ukuran'];
		
	$sql= "SELECT * FROM ukuran_bajumelayu WHERE id = '$id' AND bajuID = '$bajuID' ";						 
	$result = mysql_query($sql) or die('Query failed. ' . mysql_error());
	
	while( $row = mysql_fetch_assoc($result) )
	{
		$labuh_lengan = $row['labuh_lengan'];
		$panjang_baju = $row['panjang_baju'];
		$lilit_leher = $row['lilit_leher'];
		$lilit_dada = $row['lilit_dada'];									
	}		
?>

<body>

<div align="left" class="accordion-group breadcrumb" style="border:solid; border-color:#ccc">
<legend>Kemaskini Ukuran Baju Melayu</legend>
<form action="" method="post" name="form_kurung" id="form_kurung">
 <table class="table table-striped table-bordered " style="color:#000000; font-family:Arial, Helvetica, sans-serif; 	
      font-size:11px;" cellpadding="0" cellspacing="0" width="441" border="0">
    <tr>
      <th style="background-color:#CCC" nowrap>Labuh Lengan</th>
      <td nowrap="nowrap"><input class="input-mini" type="text" name="labuh_lengan" id="labuh_lengan" value="<?php echo $labuh_lengan?>" > inci</td>
      <th style="background-color:#CCC" nowrap>Panjang Baju</th>
      <td nowrap="nowrap"><input class="input-mini" type="text" name="panjang_baju" id="panjang_baju" value="<?php echo $panjang_baju?>" /> inci</td>
    </tr>
    <tr>
      <th style="background-color:#CCC" nowrap>Lilit Leher</th>
      <td nowrap="nowrap"><input class="input-mini" type="text" name="lilit_leher" id="lilit_leher" value="<?php echo $lilit_leher?>"> inci</td>
      <th style="background-color:#CCC" nowrap>Lilit Dada</th>
      <td nowrap="nowrap"><input class="input-mini" type="text" name="lilit_dada" id="lilit_dada" value="<?php echo $lilit_dada?>" /> inci</td>
    </tr>   
    <tr>
      <th style="background-color:#CCC" nowrap>&nbsp;</th>
      <td colspan="3" nowrap="nowrap">
      <input type="hidden" name="jnis_ukuran"  value="<?php echo $bajuID; ?>" />
      <input type="hidden" name="id"  value="<?php echo $id; ?>" />
      <input class="btn btn-mini btn-primary" type="submit" name="edit_bajumelayu" id="simpan" value="Kemaskini">
      <input class="btn btn-mini btn-danger"type="reset" name="button2" id="button2" value="Semula"></td>
    </tr>
  </table>

 </form>   
</div>
</body>
</html>