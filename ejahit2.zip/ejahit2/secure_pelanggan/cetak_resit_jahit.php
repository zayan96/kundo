<?php
	$id_plgn = $_GET['id_plgn'];
	$trans = $_GET['trans'];
	
	include '../dbconnect.php';
	
	$sql_list = "SELECT distinct ukuran_bajukurung.ID_pelanggan,
						ukuran_bajukurung.id,
						ukuran_bajukurung.bajuID,
						pelanggan.nama_penuh,
						pelanggan.alamat,
						pelanggan.notel,
						kategori,
						transactioncode,
						ambil_tarikh
				 FROM ukuran_bajukurung,jenis,pelanggan 
				 WHERE ukuran_bajukurung.ID_pelanggan = '$id_plgn' AND transactioncode = '$trans' AND (ukuran_bajukurung.bajuID=jenis.bajuID) AND (ukuran_bajukurung.ID_pelanggan=pelanggan.ID_pelanggan)
				 UNION
				 SELECT distinct ukuran_bajumelayu.ID_pelanggan,
						ukuran_bajumelayu.id,
						ukuran_bajumelayu.bajuID,
						pelanggan.nama_penuh,
						pelanggan.alamat,
						pelanggan.notel,
						kategori,
						transactioncode,
						ambil_tarikh
				 FROM ukuran_bajumelayu,jenis,pelanggan
				 WHERE ukuran_bajumelayu.ID_pelanggan = '$id_plgn' AND transactioncode = '$trans' AND (ukuran_bajumelayu.bajuID=jenis.bajuID)AND (ukuran_bajumelayu.ID_pelanggan=pelanggan.ID_pelanggan)
				 UNION
				 SELECT distinct ukuran_jubah.ID_pelanggan,
						ukuran_jubah.id,
						ukuran_jubah.bajuID,
						pelanggan.nama_penuh,
						pelanggan.alamat,
						pelanggan.notel,
						kategori,
						transactioncode,
						ambil_tarikh
				 FROM ukuran_jubah,jenis ,pelanggan
				 WHERE ukuran_jubah.ID_pelanggan = '$id_plgn' AND transactioncode = '$trans' AND (ukuran_jubah.bajuID=jenis.bajuID)AND (ukuran_jubah.ID_pelanggan=pelanggan.ID_pelanggan)
				 UNION
				 SELECT distinct ukuran_kain_kurung.ID_pelanggan,
						ukuran_kain_kurung.id,
						ukuran_kain_kurung.bajuID,
						pelanggan.nama_penuh,
						pelanggan.alamat,
						pelanggan.notel,
						kategori,
						transactioncode,
						ambil_tarikh
				 FROM ukuran_kain_kurung,jenis,pelanggan 
				 WHERE ukuran_kain_kurung.ID_pelanggan = '$id_plgn' AND transactioncode = '$trans' AND (ukuran_kain_kurung.bajuID=jenis.bajuID)AND (ukuran_kain_kurung.ID_pelanggan=pelanggan.ID_pelanggan)";					  							
	$result = mysql_query($sql_list) or die('Query failed. ' . mysql_error());
	$row = mysql_fetch_array($result, MYSQL_ASSOC);
	
?>

<?php

	$id_plgn = $id_plgn;
	$trans = $trans;
	
	$sql_list1 = "SELECT distinct ukuran_bajukurung.ID_pelanggan,
						ukuran_bajukurung.id,
						ukuran_bajukurung.bajuID,
						pelanggan.nama_penuh,
						pelanggan.alamat,
						pelanggan.notel,
						kategori,
						transactioncode,
						ambil_tarikh
				 FROM ukuran_bajukurung,jenis,pelanggan 
				 WHERE ukuran_bajukurung.ID_pelanggan = '$id_plgn' AND transactioncode = '$trans' AND (ukuran_bajukurung.bajuID=jenis.bajuID) AND (ukuran_bajukurung.ID_pelanggan=pelanggan.ID_pelanggan)
				 UNION
				 SELECT distinct ukuran_bajumelayu.ID_pelanggan,
						ukuran_bajumelayu.id,
						ukuran_bajumelayu.bajuID,
						pelanggan.nama_penuh,
						pelanggan.alamat,
						pelanggan.notel,
						kategori,
						transactioncode,
						ambil_tarikh
				 FROM ukuran_bajumelayu,jenis,pelanggan
				 WHERE ukuran_bajumelayu.ID_pelanggan = '$id_plgn' AND transactioncode = '$trans' AND (ukuran_bajumelayu.bajuID=jenis.bajuID)AND (ukuran_bajumelayu.ID_pelanggan=pelanggan.ID_pelanggan)
				 UNION
				 SELECT distinct ukuran_jubah.ID_pelanggan,
						ukuran_jubah.id,
						ukuran_jubah.bajuID,
						pelanggan.nama_penuh,
						pelanggan.alamat,
						pelanggan.notel,
						kategori,
						transactioncode,
						ambil_tarikh
				 FROM ukuran_jubah,jenis ,pelanggan
				 WHERE ukuran_jubah.ID_pelanggan = '$id_plgn' AND transactioncode = '$trans' AND (ukuran_jubah.bajuID=jenis.bajuID)AND (ukuran_jubah.ID_pelanggan=pelanggan.ID_pelanggan)
				 UNION
				 SELECT distinct ukuran_kain_kurung.ID_pelanggan,
						ukuran_kain_kurung.id,
						ukuran_kain_kurung.bajuID,
						pelanggan.nama_penuh,
						pelanggan.alamat,
						pelanggan.notel,
						kategori,
						transactioncode,
						ambil_tarikh
				 FROM ukuran_kain_kurung,jenis,pelanggan 
				 WHERE ukuran_kain_kurung.ID_pelanggan = '$id_plgn' AND transactioncode = '$trans' AND (ukuran_kain_kurung.bajuID=jenis.bajuID)AND (ukuran_kain_kurung.ID_pelanggan=pelanggan.ID_pelanggan)
				 UNION
				 SELECT distinct ukuran_kemeja.ID_pelanggan,
						ukuran_kemeja.id,
						ukuran_kemeja.bajuID,
						pelanggan.nama_penuh,
						pelanggan.alamat,
						pelanggan.notel,
						kategori,
						transactioncode,
						ambil_tarikh
				 FROM ukuran_kemeja,jenis,pelanggan 
				 WHERE ukuran_kemeja.ID_pelanggan = '$id_plgn' AND transactioncode = '$trans' AND (ukuran_kemeja.bajuID=jenis.bajuID)AND (ukuran_kemeja.ID_pelanggan=pelanggan.ID_pelanggan)
				 UNION
				 SELECT distinct ukuran_seluar.ID_pelanggan,
						ukuran_seluar.id,
						ukuran_seluar.bajuID,
						pelanggan.nama_penuh,
						pelanggan.alamat,
						pelanggan.notel,
						kategori,
						transactioncode,
						ambil_tarikh
				 FROM ukuran_seluar,jenis,pelanggan
				 WHERE ukuran_seluar.ID_pelanggan = '$id_plgn' AND transactioncode = '$trans' AND (ukuran_seluar.bajuID=jenis.bajuID) AND (ukuran_seluar.ID_pelanggan=pelanggan.ID_pelanggan)";					  							
	$result_list = mysql_query($sql_list1) or die('Query failed. ' . mysql_error());

?>



<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link rel="stylesheet" type="text/css" href="../css/bootstrap.css"/>
<link rel="stylesheet" type="text/css" href="../css/stylesheet.css"/>
<title>e-Tailoring</title>
</head>

<body>      
	<br />        
    <div class="container layoutcontainer" style="height:700px;">
		<div class="accordion-group breadcrumb" style="border:solid; border-color:#ccc">
        <legend style="color:#0066CC"><h3>Resit Tempahan</h3></legend>
        <form class="form-horizontal" action="" method="post" name="form1" id="form1" autocomplete="off"  >
        
        <table width="47%" border="0" class="table table-bordered alert-info" style="color:#000000" >
          <tbody>
            <tr>
                <td width="11%" nowrap="nowrap">Nama Penuh </td>
                <th width="89%"><?php echo $row['nama_penuh']?></th>     
            </tr>
           
            <tr>
                <td nowrap="nowrap">Alamat</td>
                <th><?php echo $row['alamat']?></th>
            </tr>
            <tr>
                <td nowrap="nowrap">No.Telefon </td>
                <th><?php echo $row['notel']?></th>
            </tr>
            <tr>
                <td nowrap="nowrap">Kod Transaksi </td>
                <th><?php echo $row['transactioncode']?></th>
            </tr>
           </tbody>
         </table>             
        </form>
		  
        </div>  
        <table class="table table-striped table-bordered" id="view" style="color:#000000; font-family:Arial, Helvetica, sans-serif;font-size:11px;" cellpadding="0" cellspacing="0">
        <thead>
            <tr style="background-color:#F9C">
                <th width="20">Bil.</th>
                <th width="50">ID Baju</th>
                <th width="100">Kategori</th>
                <th width="100">ID Pelanggan</th>
                <th width="100">Tarikh Jangka Siap</th>
                <th width="100">Harga (RM)</th>
                <th width="200">Catatan</th>
            </tr>    
        </thead>
        <tbody>
		<?php 
                        
            $tmpCount = 1; 
            while($row_list = mysql_fetch_assoc($result_list)) {?>        
            <tr>
                <td><?php echo $tmpCount; ?></td>
                <td><?php echo $row_list['bajuID'];; ?></td>
                <td><?php echo $row_list['kategori']; ?></td>
                <td><?php echo $row_list['ID_pelanggan']; ?></td>
                <td><?php echo date("d/m/Y", strtotime($row_list['ambil_tarikh'])) ?></td>
                <td>&nbsp;</td>
                <td>&nbsp;</td>
           </tr>     
        <?php $tmpCount ++; }?>   
    </tbody>     
 </table>
<div>
	<input class="btn btn-mini" type="button" value="Cetak" onclick="window.print()" />
</div>
</form>    
    </div>      
</body>
</html>

