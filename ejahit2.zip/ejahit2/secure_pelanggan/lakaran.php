<?php

	include '../dbconnect.php';
	
	if (isset($_GET['bil']))
	{
		$id = $_GET['bil'];
		
		$sql_jnis = "SELECT * FROM jenis WHERE bajuID = '$id'";						 
		$result_jnis = mysql_query($sql_jnis) or die('Query failed. ' . mysql_error());
		
		while( $row_jnis = mysql_fetch_assoc($result_jnis) )
		{
			$image=$row_jnis['image'];
												
		}	
	}
	
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<script type="text/javascript" src="../js/validation.js"></script>
<link href="../css/stylesheet.css" rel="stylesheet" type="text/css" />
<title>e-Tailoring</title>

<script>

$(function() {
  $('#btn_close').click($.facebox.close);
});

</script>

</head>
<body>

<div align="left" class="accordion-group breadcrumb" style="border:solid; border-color:#ccc">
<legend>Lakaran / Gambar</legend>
 <table width="300" border="0">
   <tr>
    <td align="center" nowrap="nowrap"><label class="control-label"><img src="../jenis/<?php echo $image; ?>" height="150px" /></label></td>
    </tr>
</table>      

<div class="modal-footer">
	<input type="button" id="btn_close" class="btn btn-danger" value="Tutup" />   
</div> 
 
</div>
</body>
</html>