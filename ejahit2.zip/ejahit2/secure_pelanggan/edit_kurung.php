<?php

	include '../dbconnect.php';
	
	$jnis_kategori = $_GET['kategori'];
	$id = $_GET['id'];
	$id_plgn = $_GET['id_plgn'];
	$bajuID = $_GET['jnis_ukuran'];
		
	$sql= "SELECT * FROM ukuran_bajukurung WHERE id = '$id' AND bajuID = '$bajuID' ";						 
	$result = mysql_query($sql) or die('Query failed. ' . mysql_error());
	
	while( $row = mysql_fetch_assoc($result) )
	{
		$bukaan_tangan = $row['bukaan_tangan'];
		$lilit_ketiak = $row['lilit_ketiak'];
		$panjang_baju = $row['panjang_baju'];
		$ukuran_bahu = $row['ukuran_bahu'];
		$ukuran_dada = $row['ukuran_dada'];
		$ukuran_pinggul = $row['ukuran_pinggul'];	
		
													
	}		
?>

<body>

<div align="left" class="accordion-group breadcrumb" style="border:solid; border-color:#ccc">
<legend>Kemaskini Ukuran Baju Kurung</legend>
<form action="" method="post" name="form_kurung" id="form_kurung">
 <table class="table table-striped table-bordered " style="color:#000000; font-family:Arial, Helvetica, sans-serif; 	
      font-size:11px;" cellpadding="0" cellspacing="0"  border="0">
    <tr>
      <th width="133" style="background-color:#CCC" nowrap>Bukaan Tangan</th>
      <td width="130" nowrap="nowrap"><input class="input-mini" type="text" name="bukaan_tangan" id="bukaan_tangan" value="<?php echo $bukaan_tangan?>"> inci</td>
      <th width="155" style="background-color:#CCC" nowrap>Lilit Ketiak</th>
      <td width="50" nowrap="nowrap"><input class="input-mini" type="text" name="lilit_ketiak" id="lilit_ketiak" value="<?php echo $lilit_ketiak?>" /> inci</td>
    </tr>
    <tr>
      <th style="background-color:#CCC" nowrap>Panjang Baju</th>
      <td nowrap="nowrap"><input class="input-mini" type="text" name="panjang_baju" id="panjang_baju" value="<?php echo $panjang_baju?>"> inci</td>
      <th style="background-color:#CCC" nowrap>Ukuran Bahu</th>
      <td nowrap="nowrap"><input class="input-mini" type="text" name="ukuran_bahu" id="ukuran_bahu" value="<?php echo $ukuran_bahu?>" /> inci</td>
    </tr>
    <tr>
      <th style="background-color:#CCC" nowrap>Ukuran Dada</th>
      <td nowrap="nowrap"><input class="input-mini" type="text" name="ukuran_dada" id="ukuran_dada" value="<?php echo $ukuran_dada?>"> inci</td>
      <th style="background-color:#CCC" nowrap>Ukuran Pinggul</th>
      <td nowrap="nowrap"><input class="input-mini" type="text" name="ukuran_pinggul" id="ukuran_pinggul" value="<?php echo $ukuran_pinggul?>" /> inci</td>
    </tr>
          
    <tr>
      <th style="background-color:#CCC" nowrap>&nbsp;</th>
      <td colspan="3" nowrap="nowrap">
      <input type="hidden" name="jnis_ukuran"  value="<?php echo $bajuID; ?>" />
      <input type="hidden" name="id"  value="<?php echo $id; ?>" />
      <input class="btn btn-mini btn-primary" type="submit" name="edit_bajukurung" id="simpan" value="Kemaskini">
      <input class="btn btn-mini btn-danger"type="reset" name="button2" id="button2" value="Semula"></td>
    </tr>
  </table>  
 </form>   
</div>
</body>
</html>