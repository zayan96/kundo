<?php

	if (isset($_GET['bil']))
	{
		$id=$_GET['bil'];
		include '../dbconnect.php';
		
		print ("<SCRIPT LANGUAGE='JavaScript'>
		var answer=window.confirm('Anda pasti ingin hapus maklumat ini?')
		if (answer){
										
			 window.location='hapus_jenis.php?delete=ya&bil=$id';					 	 
		}
		else
		{				 
			 window.location='jenis.php';
		}	
		</SCRIPT>");	
			
	}
	
?>

 <?php
 
 	if (isset($_GET['delete']))
	{		
		$id=$_GET['bil'];		
		$sql = "DELETE FROM jenis WHERE bajuID='$id'"; 
		mysql_query($sql) or die(mysql_error());
		header("location: jenis.php");				
			
	}  
 ?>