
<body>

  <table class="table table-striped table-bordered " style="color:#000000; font-family:Arial, Helvetica, sans-serif; 	
      font-size:11px;" cellpadding="0" cellspacing="0" width="441" border="0">
    <tr>
      <th style="background-color:#CCC" nowrap>Ukuran Pinggang</th>
      <td nowrap="nowrap"><input class="input-mini" type="text" name="ukur_pinggang" id="ukur_pinggang"> inci</td>
      <th style="background-color:#CCC" nowrap>Ukuran Punggung</th>
      <td nowrap="nowrap"><input class="input-mini" type="text" name="ukur_punggung" id="ukur_punggung" /> inci</td>
    </tr>
    <tr>
      <th style="background-color:#CCC" nowrap>Labuh Kain</th>
      <td nowrap="nowrap"><input class="input-mini" type="text" name="labuh_kain" id="labuh_kain"> inci</td>
      <th colspan="2"></th>
    </tr>
    <tr>
      <th style="background-color:#CCC" nowrap>Tarikh Dijangka Ambil</th>
      <td colspan="3" nowrap="nowrap"><input class="input-small" type="text" name="ambil_tarikh" id="ambil_tarikh"></td>
    </tr>
    <tr>
      <th style="background-color:#CCC" nowrap>Lampiran</th>
      <td colspan="3" nowrap="nowrap"> <input class="input-file" id="uploaded" name="uploaded" type="file" /></td>
    </tr>    
    <tr>
      <th style="background-color:#CCC" nowrap>&nbsp;</th>
      <td colspan="3" nowrap="nowrap">
      <input type="hidden" name="jnis_ukuran"  value="<?php echo $jnis_ukuran; ?>" />
      <input class="btn btn-mini btn-primary" type="submit" name="simpan_kainkurung" id="simpan" value="Simpan Ukuran">
      <input class="btn btn-mini btn-danger"type="reset" name="button2" id="button2" value="Semula"></td>
    </tr>
  </table>

</body>

