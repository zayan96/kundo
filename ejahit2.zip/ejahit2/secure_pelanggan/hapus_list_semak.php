<?php

	include '../dbconnect.php';
	$jnis_kategori = $_GET['kategori'];
	$id = $_GET['id'];
	$id_plgn = $_GET['id_plgn'];
	$bajuID = $_GET['jnis_ukuran'];
	$trans = $_GET['trans'];
	
	
	if ($jnis_kategori=='Kain Kurung')
	{
		$sql = "DELETE FROM ukuran_kain_kurung WHERE id='$id'"; 
		mysql_query($sql) or die(mysql_error());		
	}
	
	if ($jnis_kategori=='Baju Melayu')
	{
		$sql = "DELETE FROM ukuran_bajumelayu WHERE id='$id'"; 
		mysql_query($sql) or die(mysql_error());			
	}
	
	
	if ($jnis_kategori=='Jubah')
	{
		$sql = "DELETE FROM ukuran_jubah WHERE id='$id'"; 
		mysql_query($sql) or die(mysql_error());			
	}
	
	if ($jnis_kategori=='Baju Kurung')
	{
		$sql = "DELETE FROM ukuran_bajukurung WHERE id='$id'"; 
		mysql_query($sql) or die(mysql_error());		
	}
	
	print "<script type='text/javascript'>self.location='semak_tempahan.php?id_plgn=$id_plgn&trans=$trans';</script>";

?>

