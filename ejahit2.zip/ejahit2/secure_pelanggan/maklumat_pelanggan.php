<?php 
		
	$sql1 = "SELECT * FROM pelanggan
			 WHERE ID_pelanggan = $id_plgn";					  							
    $result1 = mysql_query($sql1) or die('Query failed. ' . mysql_error());
	$row1 = mysql_fetch_assoc($result1)
		
?>

<?php

	if(isset($_POST['jnis_ukuran']) || isset($_GET['jnis_ukuran']))
	{
		if (isset($_POST['jnis_ukuran']))
		{			
			$jnis_ukuran = $_POST['jnis_ukuran'];			
		}						
	}
	else
	{
		$jnis_ukuran = "";		
	}
?>

     <table class="table table-bordered">
      <tbody>
        <tr>
            <td width="10%">Nama Penuh </td>
            <th width="40%"><?php echo $row1['nama_penuh']?></th>     
        </tr>
       
        <tr>
            <td>Alamat</td>
            <th><?php echo $row1['alamat']?></th>
        </tr>
        <tr>
            <td>No.Telefon </td>
            <th><?php echo $row1['notel']?></th>
        </tr>
       </tbody>
     </table>
     
     <table  width="100%" class=" table breadcrumb " border="0" cellpadding="0">
     	<tr><td>Kod Transaksi Pelanggan :</td><th align="left"><font color="DarkGreen"><?php if($_SESSION['Transcode']<>""):echo $_SESSION['Transcode']; else: echo "";?><?php endif?></font></th></tr>
     	<tr>
        	<td style="text-align:left" valign="top">
            	<div class="text"><h2>Jenis Ukuran</h2></div>
                 <div class="view1">         
                  <div class="control-group">
                      <div class="controls">
                      <form action="" method="post" name="form_jnis" id="form_jnis">
                        <select name="jnis_ukuran" id="jnis_ukuran" style="width:auto" class="required" onchange="submit()">
                        <option>--Pilih Jenis--</option>
                         <?php 
            
                        $sql="SELECT * FROM jenis ORDER BY kategori";	
                        $r = mysql_query($sql) or die('Query failed. ' . mysql_error());
                                
                        while ($row = mysql_fetch_assoc($r)){          
                        ?>      
                        <option value="<?php echo $row['bajuID'];?>"<?php if(!(strcmp($row['bajuID'],$jnis_ukuran))){echo "selected=\"selected\""; }?>> 
                        <?php echo $row['kategori']." - ".$row['bajuID']; ?>
                        <?php 
                         }
                        ?>
                        </select>  
                      </form>
                      </div> 
                   </div> 
                   <?php
				 
				 	 $sql2="SELECT * FROM jenis WHERE bajuID='$jnis_ukuran'";	
					 $r2 = mysql_query($sql2) or die('Query failed. ' . mysql_error());
					 $row2 = mysql_fetch_assoc($r2);
					
					 $jnis_ukuran = $row2['bajuID'];
					 $image = $row2['image']; 
				 ?>
                       
            	<div style="vertical-align:top" align="center"><img src="../jenis/<?php echo $image; ?>"  height="150px" /></div>        						  
                 </div>     
                 </td>
            
            <td align="right" style="text-align:right" valign="top">
            
            <div id="templatemo_content_right">
			<form enctype="multipart/form-data" method="post" action="" id="form3" name="form3" autocomplete="off">
            <input name="id_plgn" type="hidden" value="<?php echo $row1['ID_pelanggan']?>" />
            <input name="transactioncode" type="hidden" value="<?php echo $_SESSION['Transcode']; ?>" />
	    	<h2>Maklumat Ukuran Pelanggan </h2>
               
            <?php
				
				$sql1="SELECT * FROM jenis WHERE bajuID='$jnis_ukuran'";	
                $r1 = mysql_query($sql1) or die('Query failed. ' . mysql_error());
				$row1 = mysql_fetch_assoc($r1);
				
				$jnis_ukuran = $row1['bajuID'];
				$jnis_kategori = $row1['kategori'];
					
				
				if($jnis_kategori=='Kain Kurung')
				{
					require 'ukuran_kainkurung.php';		
				}
				elseif($jnis_kategori=='Baju Melayu')
				{		
					require 'ukuran_bajumelayu.php';		
				}
				elseif($jnis_kategori=='Baju Kurung')
				{
					require 'ukuran_bajukurung.php';				
				}
				elseif($jnis_kategori=='Jubah')
				{
					require 'ukuran_jubah.php';					
				}
					
			?>
             
      <br />    
	  </form>
     </div>                       
        </td>      
        </tr>
        <tr>
        <td colspan="2">
        <form action="" method="post" name="form_htr" id="form_htr">
        <table class="table table-striped table-bordered" id="view" style="color:#000000; font-family:Arial, Helvetica, sans-serif;font-size:11px;" cellpadding="0" cellspacing="0">
            <thead>
                <tr style="background-color:#F9C">
                    <th width="20">Bil.</th>
                    <th width="250">ID Baju</th>
                    <th width="173">Kategori</th>
                    <th width="143">ID Pelanggan</th>
                    <th width="100">Tindakan</th>
                </tr>    
            </thead>
            <tbody>
            <?php 
				
				$id_plgn = $id_plgn;
				$trans = $_SESSION['Transcode'];
				
				$sql_list = "SELECT distinct ID_pelanggan,
									id,
							        ukuran_bajukurung.bajuID,
									kategori
							 FROM ukuran_bajukurung,jenis 
							 WHERE ID_pelanggan = '$id_plgn' AND transactioncode = '$trans' AND (ukuran_bajukurung.bajuID=jenis.bajuID)
							 UNION
							 SELECT distinct ID_pelanggan,
							 		id,
							        ukuran_bajumelayu.bajuID,
									kategori
							 FROM ukuran_bajumelayu,jenis
							 WHERE ID_pelanggan = '$id_plgn' AND transactioncode = '$trans' AND (ukuran_bajumelayu.bajuID=jenis.bajuID)
							 UNION
							 SELECT distinct ID_pelanggan,
							 		id,
							        ukuran_jubah.bajuID,
									kategori
							 FROM ukuran_jubah,jenis 
							 WHERE ID_pelanggan = '$id_plgn' AND transactioncode = '$trans' AND (ukuran_jubah.bajuID=jenis.bajuID)
							 UNION
							 SELECT distinct ID_pelanggan,
							 		id,
							        ukuran_kain_kurung.bajuID,
									kategori
							 FROM ukuran_kain_kurung,jenis 
							 WHERE ID_pelanggan = '$id_plgn' AND transactioncode = '$trans' AND (ukuran_kain_kurung.bajuID=jenis.bajuID)";
							   							
    		    $result_list = mysql_query($sql_list) or die('Query failed. ' . mysql_error());
				
			
        		$tmpCount = 1; 
        		while($row_list = mysql_fetch_assoc($result_list)) {?>        
        		<tr>
          			<td><a href="" data-toggle="modal" class="btn btn-mini btn-info"><?php echo $tmpCount; ?></a></td>
                    <td><?php echo $row_list['bajuID'];; ?></td>
                    <td><?php echo $row_list['kategori']; ?></td>
                    <td><?php echo $row_list['ID_pelanggan']; ?></td>
          			<td>
                    <a href="hapus_list.php?kategori=<?php echo $row_list['kategori'];?>&id=<?php echo $row_list['id'];?>&id_plgn=<?php echo $row_list['ID_pelanggan'];?>&jnis_ukuran=<?php echo $row_list['bajuID'];?>"class="btn btn-mini btn-danger">Hapus</a> |
                    <?php
					
						if($row_list['kategori']=="Seluar")
						{
							$url="edit_seluar.php";
						}
						elseif($row_list['kategori']=="Kemeja")
						{
							$url="edit_kemeja.php";
						}
						elseif($row_list['kategori']=="Kain Kurung")
						{
							$url="edit_kain.php";
						}
						elseif($row_list['kategori']=="Baju Melayu")
						{
							$url="edit_melayu.php";
						}
						elseif($row_list['kategori']=="Jubah")
						{
							$url="edit_jubah.php";
						}
						elseif($row_list['kategori']=="Baju Kurung")
						{
							$url="edit_kurung.php";
						}
						else
						{
							$url="";
							
						}
					
					?>
                    <a rel="facebox" href="<?php echo $url;?>?kategori=<?php echo $row_list['kategori'];?>&id=<?php echo $row_list['id'];?>&id_plgn=<?php echo $row_list['ID_pelanggan'];?>&jnis_ukuran=<?php echo $row_list['bajuID'];?>"class="btn btn-mini btn-primary">Edit</a>
                    </td>
        	   </tr>     
            <?php $tmpCount ++; }?>   
            </tbody>     
         </table>
         	<a target="_blank" href="cetak_resit_jahit.php?id_plgn=<?php echo $id_plgn;?>&trans=<?php echo $trans?>"class="btn btn-inverse">Cetak Resit</a>
        	<input name="jnis_ukuran" type="hidden" value="<?php echo $jnis_ukuran;?>" />
        </form>
        </td>
        </tr>  
    </table>
     
     
      
    
