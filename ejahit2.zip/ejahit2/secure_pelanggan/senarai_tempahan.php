<?php

	$id_plgn = $id_plgn;
	$trans = $trans;
	
	$sql_list = "SELECT distinct ID_pelanggan,
						id,
						ukuran_bajukurung.bajuID,
						kategori,
						transactioncode
				 FROM ukuran_bajukurung,jenis 
				 WHERE ID_pelanggan = '$id_plgn' AND transactioncode = '$trans' AND (ukuran_bajukurung.bajuID=jenis.bajuID)
				 UNION
				 SELECT distinct ID_pelanggan,
						id,
						ukuran_bajumelayu.bajuID,
						kategori,
						transactioncode
				 FROM ukuran_bajumelayu,jenis
				 WHERE ID_pelanggan = '$id_plgn' AND transactioncode = '$trans' AND (ukuran_bajumelayu.bajuID=jenis.bajuID)
				 UNION
				 SELECT distinct ID_pelanggan,
						id,
						ukuran_jubah.bajuID,
						kategori,
						transactioncode
				 FROM ukuran_jubah,jenis 
				 WHERE ID_pelanggan = '$id_plgn' AND transactioncode = '$trans' AND (ukuran_jubah.bajuID=jenis.bajuID)
				 UNION
				 SELECT distinct ID_pelanggan,
						id,
						ukuran_kain_kurung.bajuID,
						kategori,
						transactioncode
				 FROM ukuran_kain_kurung,jenis 
				 WHERE ID_pelanggan = '$id_plgn' AND transactioncode = '$trans' AND (ukuran_kain_kurung.bajuID=jenis.bajuID)";					  							
	$result_list = mysql_query($sql_list) or die('Query failed. ' . mysql_error());

?>

<form action="" method="post" name="form_1" id="form_1">
<table class="table table-striped table-bordered" id="view" style="color:#000000; font-family:Arial, Helvetica, sans-serif;font-size:11px;" cellpadding="0" cellspacing="0">
    <thead>
        <tr style="background-color:#1993E9">
            <th width="20">Bil.</th>
            <th width="250">ID Baju</th>
            <th width="173">Kategori</th>
            <th width="143">ID Pelanggan</th>
            <th width="100">Kod Transaksi</th>
            <th width="100">Tindakan</th>
        </tr>    
    </thead>
    <tbody>
    <?php 
                    
        $tmpCount = 1; 
        while($row_list = mysql_fetch_assoc($result_list)) {?>        
        <tr>
            <td><a href="" data-toggle="modal" class="btn btn-mini btn-info"><?php echo $tmpCount; ?></a></td>
            <td><?php echo $row_list['bajuID'];; ?></td>
            <td><?php echo $row_list['kategori']; ?></td>
            <td><?php echo $row_list['ID_pelanggan']; ?></td>
            <td><?php echo $row_list['transactioncode']; ?></td>
            <td>
            <a href="hapus_list_semak.php?kategori=<?php echo $row_list['kategori'];?>&id=<?php echo $row_list['id'];?>&id_plgn=<?php echo $row_list['ID_pelanggan'];?>&jnis_ukuran=<?php echo $row_list['bajuID'];?>&trans=<?php echo $row_list['transactioncode'];?>" class="btn btn-mini btn-danger">Hapus</a> |
            <?php
            
               
                if($row_list['kategori']=="Kain Kurung")
                {
                    $url="edit_kain.php";
                }
                elseif($row_list['kategori']=="Baju Melayu")
                {
                    $url="edit_melayu.php";
                }
                elseif($row_list['kategori']=="Jubah")
                {
                    $url="edit_jubah.php";
                }
                elseif($row_list['kategori']=="Baju Kurung")
                {
                    $url="edit_kurung.php";
                }
                else
                {
                    $url="";          
                }          
            ?>
            <a rel="facebox" href="<?php echo $url;?>?kategori=<?php echo $row_list['kategori'];?>&id=<?php echo $row_list['id'];?>&id_plgn=<?php echo $row_list['ID_pelanggan'];?>&jnis_ukuran=<?php echo $row_list['bajuID'];?>&trans=<?php echo $row_list['transactioncode'];?>"class="btn btn-mini btn-primary">Edit</a>
            </td>
       </tr>     
    <?php $tmpCount ++; }?>   
    </tbody>     
 </table>
 
 <a target="_blank" href="cetak_resit_jahit.php?id_plgn=<?php echo $id_plgn;?>&trans=<?php echo $trans?>"class="btn btn-inverse">Cetak Resit</a>
</form>